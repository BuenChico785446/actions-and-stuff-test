package traben.entity_model_features.mixin.mixins.rendering.feature;


import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.layers.SlimeOuterLayer;
import org.spongepowered.asm.mixin.*;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import traben.entity_model_features.models.animation.state.EMFState;

//#if MC>= 12111
//$$ import net.minecraft.client.renderer.rendertype.RenderTypes;
//#else
import net.minecraft.client.renderer.RenderType;
//#endif

@Mixin(SlimeOuterLayer.class)
public class MixinSlimeOverlayFeatureRenderer {



    @Inject(method =
//#if MC >=12109
            "submit(Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/SubmitNodeCollector;ILnet/minecraft/client/renderer/entity/state/SlimeRenderState;FF)V",
//#elseif MC >=12102
//$$ "render(Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource;ILnet/minecraft/client/renderer/entity/state/SlimeRenderState;FF)V",
//#else
//$$             "render(Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource;ILnet/minecraft/world/entity/LivingEntity;FFFFFF)V",
//#endif
            at = @At(value = "HEAD"))
    private void emf$setLayerForOverrides(CallbackInfo ci) {
        if (EMFState.state() == null) return;
        EMFState.state().setLayerFactory(
                //#if MC>= 12111
                //$$ RenderTypes
                //#else
                RenderType
                //#endif
                ::entityTranslucent);
    }
}
