package traben.entity_model_features.propeties;

import org.jetbrains.annotations.NotNull;
import traben.entity_model_features.models.animation.math.expression_tree.MathValue;
import traben.entity_model_features.utils.EMFEntity;
import traben.entity_texture_features.features.property_reading.properties.RandomProperty;
import traben.entity_texture_features.features.state.ETFEntityRenderState;

import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

public class EntityVariableBooleanProperty extends RandomProperty {
    private final Map<String, Boolean> VARIABLE_MAP;

    protected EntityVariableBooleanProperty(Properties properties, int propertyNum) throws RandomProperty.RandomPropertyException {
        String keyPrefix = "varb." + propertyNum + ".";
        this.VARIABLE_MAP = new HashMap<>();
        properties.forEach((key, value) -> {
            if (key != null && ((String) key).startsWith(keyPrefix)) {
                String instruction = ((String) value).trim();
                String variableKey = "varb." + ((String) key).replaceAll(keyPrefix, "");
                if (!variableKey.isBlank() && !instruction.isBlank()) {
                    boolean matchTrue = instruction.contains("true");
                    this.VARIABLE_MAP.put(variableKey, matchTrue);
                }
            }

        });
        if (this.VARIABLE_MAP.isEmpty()) {
            throw new RandomProperty.RandomPropertyException("Variable booleans failed");
        }
    }

    public static EntityVariableBooleanProperty getPropertyOrNull(Properties properties, int propertyNum) {
        try {
            return new EntityVariableBooleanProperty(properties, propertyNum);
        } catch (RandomProperty.RandomPropertyException var3) {
            return null;
        }
    }

    @Override
    protected boolean testEntityInternal(final ETFEntityRenderState etfEntity) {
        if (etfEntity != null && etfEntity.entity() instanceof EMFEntity IEMFEntity) {
            for (Map.Entry<String, Boolean> stringFunctionEntry : VARIABLE_MAP.entrySet()) {
                boolean value = MathValue.toBoolean(
                        IEMFEntity.emf$getVariableMap().getOrDefault(stringFunctionEntry.getKey(), MathValue.FALSE)
                );
                if (stringFunctionEntry.getValue() != value) {
                    return false;
                }
            }
            return true;
        }
        return false;
    }

    public @NotNull String[] getPropertyIds() {
        return new String[]{"varb"};
    }

    @Override
    protected String getPrintableRuleInfo() {
        return null;
    }
}
