---
name: Feature request
about: Suggest an idea for EMF
title: "[Idea] new feature"
labels: enhancement
assignees: Traben-0

---

**Is your feature request related to a problem? Please describe.**
A clear and concise description of what the problem is. Ex. I'm always frustrated when [...]

**Describe the solution you'd like**
A clear and concise description of what you want to happen.

**Does OptiFine do this**
Does OptiFine do this, and if so, how?

**Additional context**
Add any other context or screenshots about the feature request here.
