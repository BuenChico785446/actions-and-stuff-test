package mod.azure.azurelib.hitbox.client;

import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.SubmitNodeCollector;
import net.minecraft.client.renderer.rendertype.RenderTypes;
import net.minecraft.client.renderer.state.level.CameraRenderState;
import net.minecraft.util.ARGB;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.shapes.Shapes;
import org.joml.Matrix3f;
import org.joml.Quaternionf;
import org.joml.Vector3f;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import mod.azure.azurelib.AzureLib;
import mod.azure.azurelib.hitbox.*;
import mod.azure.azurelib.model.AzBakedModel;
import mod.azure.azurelib.model.AzBone;
import mod.azure.azurelib.network.packet.AzHitboxAttackPacket;
import mod.azure.azurelib.network.packet.AzHitboxInteractPacket;
import mod.azure.azurelib.platform.Services;
import mod.azure.azurelib.render.entity.AzEntityRenderer;

public final class AzHitboxClientHooks {

    private static final double REPORT_RANGE = 64;

    private static final Set<String> WARNED_MISSING = new HashSet<>();

    private static final Vector3f SCRATCH_CENTER = new Vector3f();

    private static final Vector3f SCRATCH_SCALE = new Vector3f();

    private static final Quaternionf SCRATCH_ROTATION = new Quaternionf();

    private AzHitboxClientHooks() {
        throw new UnsupportedOperationException();
    }

    public static void afterEntityRender(Entity entity, AzBakedModel model, float partialTick) {
        if (!(entity instanceof AzHitboxHolder)) {
            return;
        }

        var state = AzHitboxes.getOrCreateState(entity);

        if (state == null) {
            return;
        }

        capture(entity, model, state, partialTick);
        AzHitboxClientAccess.markRendered(state, entity.level().getGameTime());
        report(entity, state);
    }

    public static void collectDebugBoxes(Entity entity, float partialTick, List<AzHitboxDebugBox> out) {
        var state = AzHitboxes.getLiveState(entity);

        if (state == null) {
            return;
        }

        var lerped = entity.getPosition(partialTick);
        var offsetX = lerped.x - entity.getX();
        var offsetY = lerped.y - entity.getY();
        var offsetZ = lerped.z - entity.getZ();
        var boxes = state.worldBoxes(entity);
        var set = state.set();

        for (int i = 0; i < boxes.length; i++) {
            var box = boxes[i];

            if (box == null) {
                continue;
            }

            var hitbox = set.get(i);
            var multiplier = hitbox.damageMultiplier();
            float r = 0.2f, g = 1f, b = 0.2f;

            if (hitbox.role() == AzHitboxRole.INTERACT) {
                r = 0.2f;
                g = 0.9f;
                b = 0.9f;
            } else if (hitbox.role() == AzHitboxRole.ANCHOR) {
                r = 1f;
                g = 0.85f;
                b = 0.1f;
            } else if (multiplier > 1) {
                r = 1f;
                g = 0.25f;
                b = 0.25f;
            } else if (multiplier < 1) {
                r = 0.3f;
                g = 0.5f;
                b = 1f;
            }

            var axisX = box.axisX();
            var axisY = box.axisY();
            var axisZ = box.axisZ();
            var rotation = new Quaternionf().setFromNormalized(
                new Matrix3f(
                    (float) axisX.x,
                    (float) axisX.y,
                    (float) axisX.z,
                    (float) axisY.x,
                    (float) axisY.y,
                    (float) axisY.z,
                    (float) axisZ.x,
                    (float) axisZ.y,
                    (float) axisZ.z
                )
            );

            out.add(
                new AzHitboxDebugBox(
                    box.centerX() + offsetX,
                    box.centerY() + offsetY,
                    box.centerZ() + offsetZ,
                    (float) box.halfExtentX(),
                    (float) box.halfExtentY(),
                    (float) box.halfExtentZ(),
                    rotation,
                    ARGB.colorFromFloat(1f, r, g, b)
                )
            );
        }
    }

    public static void submitDebugBoxes(
        List<AzHitboxDebugBox> boxes,
        CameraRenderState camera,
        SubmitNodeCollector collector
    ) {
        if (boxes.isEmpty()) {
            return;
        }

        var gameRenderer = Minecraft.getInstance().gameRenderer;
        var lineWidth = gameRenderer.gameRenderState().windowRenderState.appropriateLineWidth;
        var renderType = gameRenderer.useImprovedTransparency()
            ? RenderTypes.linesTranslucentNoDepthWrite()
            : RenderTypes.linesTranslucent();
        var poseStack = new PoseStack();
        var cameraPos = camera.pos;

        for (var box : boxes) {
            poseStack.pushPose();
            poseStack.translate(
                box.centerX() - cameraPos.x,
                box.centerY() - cameraPos.y,
                box.centerZ() - cameraPos.z
            );
            poseStack.rotate(box.rotation());
            collector.submitShapeOutline(
                poseStack,
                Shapes.create(-box.halfX(), -box.halfY(), -box.halfZ(), box.halfX(), box.halfY(), box.halfZ()),
                renderType,
                box.color(),
                lineWidth,
                false
            );
            poseStack.popPose();
        }
    }

    public static void afterOffscreenPose(Entity entity, AzBakedModel model, float partialTick) {
        var state = AzHitboxes.getOrCreateState(entity);

        if (state == null) {
            return;
        }

        capture(entity, model, state, partialTick);
        report(entity, state);
    }

    public static void tickOffscreen() {
        var minecraft = Minecraft.getInstance();
        var level = minecraft.level;
        var player = minecraft.player;

        if (level == null || player == null || minecraft.getConnection() == null) {
            return;
        }

        var now = level.getGameTime();
        var dispatcher = minecraft.getEntityRenderDispatcher();

        for (var entity : level.entitiesForRendering()) {
            if (!(entity instanceof AzHitboxHolder) || entity.isRemoved()) {
                continue;
            }

            if (player.distanceToSqr(entity) > REPORT_RANGE * REPORT_RANGE) {
                continue;
            }

            var state = AzHitboxes.getOrCreateState(entity);

            if (state == null || AzHitboxClientAccess.wasRenderedSince(state, now - 1)) {
                continue;
            }

            if (!AzHitboxSync.isReportDue(state, now)) {
                continue;
            }

            if (dispatcher.getRenderer(entity) instanceof AzEntityRenderer<?> renderer) {
                poseOffscreen(renderer, entity);
            }
        }
    }

    @SuppressWarnings("unchecked")
    private static <E extends Entity> void poseOffscreen(AzEntityRenderer<?> renderer, Entity entity) {
        ((AzEntityRenderer<E>) renderer).poseOffscreen((E) entity, 0f);
    }

    private static void capture(Entity entity, AzBakedModel model, AzHitboxState state, float partialTick) {
        var set = state.set();
        var fits = AzHitboxClientAccess.fitCache(state, model.getModelUUID());

        for (int i = 0; i < set.size(); i++) {
            var hitbox = set.get(i);
            var bone = model.getBoneOrNull(hitbox.bone());

            if (bone == null) {
                warnMissing(entity, hitbox);
                AzHitboxClientAccess.setInactive(state, i);
                continue;
            }

            if (!bone.isTrackingMatrices()) {
                bone.setTrackingMatrices(true);
                AzHitboxClientAccess.setInactive(state, i);
                continue;
            }

            var visibility = visibility(bone);

            if (visibility == Visibility.HIDDEN) {
                AzHitboxClientAccess.setInactive(state, i);
                continue;
            }

            if (visibility == Visibility.STALE) {
                continue;
            }

            if (fits[i] == null) {
                fits[i] = fitBoneSpaceBox(bone, hitbox);
            }

            var box = fits[i];

            if (box == null) {
                AzHitboxClientAccess.setInactive(state, i);
                continue;
            }

            var matrix = bone.getLocalSpaceMatrix();
            var center = matrix.transformPosition(box[0], box[1], box[2], SCRATCH_CENTER);
            var scale = matrix.getScale(SCRATCH_SCALE);
            var rotation = matrix.getNormalizedRotation(SCRATCH_ROTATION);

            AzHitboxClientAccess.setBox(
                state,
                i,
                center.x,
                center.y,
                center.z,
                box[3] * Math.abs(scale.x),
                box[4] * Math.abs(scale.y),
                box[5] * Math.abs(scale.z),
                rotation.x,
                rotation.y,
                rotation.z,
                rotation.w
            );
        }

        AzHitboxClientAccess.commit(state, entity, entity.level().getGameTime(), renderYaw(entity, partialTick));
    }

    private static float[] fitBoneSpaceBox(AzBone bone, AzHitbox hitbox) {
        var pivotX = bone.getPivotX() / 16f;
        var pivotY = bone.getPivotY() / 16f;
        var pivotZ = bone.getPivotZ() / 16f;

        float minX = Float.POSITIVE_INFINITY, minY = Float.POSITIVE_INFINITY, minZ = Float.POSITIVE_INFINITY;
        float maxX = Float.NEGATIVE_INFINITY, maxY = Float.NEGATIVE_INFINITY, maxZ = Float.NEGATIVE_INFINITY;
        var point = new Vector3f();

        for (var cube : bone.getCubes()) {
            var transform = cube.transform();

            for (var quad : cube.quads()) {
                if (quad == null) {
                    continue;
                }

                for (var vertex : quad.vertices()) {
                    point.set(vertex.position());

                    if (!transform.identity()) {
                        transform.pose().transformPosition(point);
                    }

                    minX = Math.min(minX, point.x - pivotX);
                    minY = Math.min(minY, point.y - pivotY);
                    minZ = Math.min(minZ, point.z - pivotZ);
                    maxX = Math.max(maxX, point.x - pivotX);
                    maxY = Math.max(maxY, point.y - pivotY);
                    maxZ = Math.max(maxZ, point.z - pivotZ);
                }
            }
        }

        var hasCubes = minX <= maxX;
        float centerX = 0, centerY = 0, centerZ = 0;
        float halfX, halfY, halfZ;

        if (hasCubes && !hitbox.anchorAtPivot()) {
            centerX = (minX + maxX) * 0.5f;
            centerY = (minY + maxY) * 0.5f;
            centerZ = (minZ + maxZ) * 0.5f;
        }

        if (hitbox.fitsCubes()) {
            if (!hasCubes) {
                AzureLib.LOGGER.warn(
                    "Hitbox '{}' fits bone '{}', which has no cubes; give it an explicit size",
                    hitbox.name(),
                    hitbox.bone()
                );
                return null;
            }

            halfX = (maxX - minX) * 0.5f;
            halfY = (maxY - minY) * 0.5f;
            halfZ = (maxZ - minZ) * 0.5f;
        } else {
            halfX = hitbox.sizeX() / 32f;
            halfY = hitbox.sizeY() / 32f;
            halfZ = hitbox.sizeZ() / 32f;
        }

        var inflate = hitbox.inflate() / 16f;
        halfX = Math.max(0, halfX + inflate);
        halfY = Math.max(0, halfY + inflate);
        halfZ = Math.max(0, halfZ + inflate);

        if (halfX == 0 && halfY == 0 && halfZ == 0) {
            return null;
        }

        return new float[] {
            centerX - hitbox.offsetX() / 16f,
            centerY + hitbox.offsetY() / 16f,
            centerZ + hitbox.offsetZ() / 16f,
            halfX,
            halfY,
            halfZ
        };
    }

    private enum Visibility {
        VISIBLE,
        HIDDEN,
        STALE
    }

    private static Visibility visibility(AzBone bone) {
        if (bone.isHidden()) {
            return bone.getLodHidden() ? Visibility.STALE : Visibility.HIDDEN;
        }

        if (isZeroScale(bone)) {
            return Visibility.HIDDEN;
        }

        for (var parent = bone.getParent(); parent != null; parent = parent.getParent()) {
            if ((parent.isHidden() && parent.isHidingChildren()) || isZeroScale(parent)) {
                return parent.getLodHidden() ? Visibility.STALE : Visibility.HIDDEN;
            }
        }

        return Visibility.VISIBLE;
    }

    private static boolean isZeroScale(AzBone bone) {
        return bone.getScaleX() == 0f && bone.getScaleY() == 0f && bone.getScaleZ() == 0f;
    }

    private static float renderYaw(Entity entity, float partialTick) {
        if (entity instanceof LivingEntity living) {
            return Mth.rotLerp(partialTick, living.yBodyRotO, living.yBodyRot);
        }

        return entity.getYRot();
    }

    private static void report(Entity entity, AzHitboxState state) {
        var minecraft = Minecraft.getInstance();
        var player = minecraft.player;

        if (player == null || minecraft.getConnection() == null || entity.level() != player.level()) {
            return;
        }

        if (player.distanceToSqr(entity) > REPORT_RANGE * REPORT_RANGE) {
            return;
        }

        if (!AzHitboxSync.shouldReport(state, entity.level().getGameTime())) {
            return;
        }

        var packet = AzHitboxSync.buildReport(entity, state);

        if (packet != null) {
            Services.NETWORK.sendToServer(packet);
        }
    }

    public static void onAttack(Player player, Entity target) {
        if (!(target instanceof AzHitboxHolder) || Minecraft.getInstance().getConnection() == null) {
            return;
        }

        var eye = player.getEyePosition();
        var reach = player.entityInteractionRange();
        var end = eye.add(player.getViewVector(1f).scale(reach));

        AzHitboxes.raycast(target, eye, end, AzHitbox::isPickable)
            .filter(hit -> hit.hitbox().role() == AzHitboxRole.COMBAT)
            .ifPresent(hit -> Services.NETWORK.sendToServer(new AzHitboxAttackPacket(target.getId(), hit.index())));
    }

    public static void onInteract(Player player, Entity target) {
        if (!(target instanceof AzHitboxHolder) || Minecraft.getInstance().getConnection() == null) {
            return;
        }

        var hit = AzHitboxInteractions.findLookedAt(player, target);

        if (hit != null) {
            Services.NETWORK.sendToServer(new AzHitboxInteractPacket(target.getId(), hit.index()));
        }
    }

    private static void warnMissing(Entity entity, AzHitbox hitbox) {
        var key = entity.getType() + "/" + hitbox.bone();

        if (WARNED_MISSING.add(key)) {
            AzureLib.LOGGER.warn(
                "Hitbox '{}' on {} references bone '{}', which is not in the model",
                hitbox.name(),
                entity.getType(),
                hitbox.bone()
            );
        }
    }
}
