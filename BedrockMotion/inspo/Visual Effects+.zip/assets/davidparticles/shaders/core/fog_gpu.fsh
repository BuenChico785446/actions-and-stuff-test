#version 330
#extension GL_ARB_separate_shader_objects : require

#include <minecraft:fog.glsl>
#include <minecraft:dynamictransforms.glsl>
#include <polytone:gpu_particle.glsl>

uniform sampler2D Sampler0;

layout(location = 0) in float sphericalVertexDistance;
layout(location = 1) in float cylindricalVertexDistance;
layout(location = 2) in vec2 texCoord0;
layout(location = 3) in vec4 vertexColor;

layout(location = 0) out vec4 fragColor;

const float FOG_WHITE_MIX = 0.25;

void main() {
    vec4 textureColor =
        texture(Sampler0, texCoord0);

    vec4 particleFogColor = vec4(
        mix(
            FogColor.rgb,
            vec3(1.0),
            FOG_WHITE_MIX
        ),
        FogColor.a
    );

    /*
     * Текстура используется как alpha-маска.
     * Цвет всегда берётся из осветлённого FogColor.
     */
    vec4 color = vec4(
        particleFogColor.rgb,
        textureColor.a *
        vertexColor.a *
        ColorModulator.a
    );

    if (color.a < AlphaCutoff) {
        discard;
    }

    fragColor = apply_fog(
        color,
        sphericalVertexDistance,
        cylindricalVertexDistance,
        FogEnvironmentalStart,
        FogEnvironmentalEnd,
        FogRenderDistanceStart,
        FogRenderDistanceEnd,
        particleFogColor
    );
}