#version 330
#extension GL_ARB_separate_shader_objects : require

#include <minecraft:fog.glsl>
#include <minecraft:dynamictransforms.glsl>
#include <polytone:gpu_particle.glsl>

layout(std140) uniform VfxUnderwaterDay { float daylight; };
layout(std140) uniform VfxUnderwaterCamera { float inWater; };
layout(std140) uniform VfxUnderwaterBrightness { float brightness; };

layout(location = 0) in vec2 rayUV;
layout(location = 1) flat in vec4 rayColor;
layout(location = 2) in vec3 rayPosition;
layout(location = 3) flat in float rayPhase;
layout(location = 0) out vec4 fragColor;

float hash(float salt) {
    return fract(sin(rayPhase * 127.1 + salt * 311.7) * 43758.5453);
}
float band(float x, float center, float width) {
    float t = (x - center) / width;
    return exp(-t * t * 2.0);
}
void main() {
    float distanceToEye = length(rayPosition);
    float nearFade = smoothstep(1.2, 3.8, distanceToEye);
    float farFade = 1.0 - smoothstep(28.0, 44.0, distanceToEye);
    float fog = total_fog_value(distanceToEye, fog_cylindrical_distance(rayPosition),
                               FogEnvironmentalStart, FogEnvironmentalEnd,
                               FogRenderDistanceStart, FogRenderDistanceEnd);
    float visibility = nearFade * farFade * (1.0 - fog) * rayColor.a
                     * clamp(daylight * 2.5, 0.0, 1.0) * clamp(inWater, 0.0, 1.0)
                     * clamp(brightness, 0.0, 2.0);
    if (visibility <= 0.0) { fragColor = vec4(0.0); return; }

    float depth = rayUV.y;
    float x = rayUV.x * 2.0 - 1.0;
    float t = Time * 0.003;
    float rows = depth; // continuous profile, no moving row boundaries
    float spread = mix(0.72, 1.0, depth);
    float bend = sin(rows * 2.0 + rayPhase + t) * 0.012;

    // A faint wide halo remains separate from the long, narrow light core.
    float haloTop = 0.025 + 0.025 * sin(x * 4.0 + rayPhase) + 0.035 * x * x;
    float haloTail = (1.0 - smoothstep(0.42, 1.0, depth)) * exp(-depth * 0.42);
    float halo = band(x, bend, spread * 0.95) * 0.12
               * smoothstep(haloTop, haloTop + 0.18, depth) * haloTail;

    // Stay visible down most of the checked water column, then dissolve near its end.
    float core = 0.0;
    float lanes = 0.0;
    float tail = 0.0;
    // Outside the narrow profiles only the broad, faint halo contributes.
    if (abs(x) < 0.66) {
        float top = 0.015 + 0.012 * sin(x * 5.0 + rayPhase);
        tail = (1.0 - smoothstep(0.74 + 0.08 * hash(9.0), 1.0, depth))
                   * exp(-depth * 0.14);
        float coreWidth = mix(0.13, 0.20, hash(11.0)) * spread;
        float coreCenter = mix(-0.12, 0.12, hash(12.0)) + bend;
        core = band(x, coreCenter, coreWidth) * 0.28
                   * smoothstep(top, top + 0.065, depth);
        for (int i = 0; i < 3; ++i) {
            float k = float(i);
            float enabled = (i < 2 || hash(20.0 + k) > 0.50) ? 1.0 : 0.0;
            float center = mix(-0.34, 0.34, hash(1.0 + k * 3.0)) * spread;
            float width = mix(0.045, 0.11, hash(2.0 + k * 3.0));
            float gain = mix(0.06, 0.13, hash(3.0 + k * 3.0));
            float laneBend = sin(rows * 2.2 + rayPhase + k * 2.1 + t) * 0.008;
            float onset = top + 0.018 * hash(30.0 + k);
            lanes += enabled * gain * band(x, center + bend + laneBend, width)
                   * smoothstep(onset, onset + 0.09, depth);
        }
    }
    float edge = 1.0 - smoothstep(0.55, 1.0, abs(x));
    float variation = (0.82 + 0.18 * hash(40.0))
                    * (0.96 + 0.04 * sin(rows * 4.0 - t + rayPhase));
    float alpha = (halo + (core + lanes) * tail) * edge * variation * visibility * 0.54;
    // Fade the trimmed halo boundary to zero to avoid a hard raster edge.
    float widthLimit = mix(0.90, 0.65, depth);
    alpha *= 1.0 - smoothstep(widthLimit - 0.04, widthLimit, abs(x));
    fragColor = vec4(rayColor.rgb * ColorModulator.rgb, alpha * ColorModulator.a);
}
