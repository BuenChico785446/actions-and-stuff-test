#version 330
#extension GL_ARB_separate_shader_objects : require

#include <minecraft:fog.glsl>
#include <minecraft:dynamictransforms.glsl>
#include <minecraft:projection.glsl>
#include <polytone:gpu_particle.glsl>

layout(std140) uniform VfxUnderwaterDay { float daylight; };
layout(std140) uniform VfxUnderwaterCamera { float inWater; };
layout(std140) uniform VfxUnderwaterBrightness { float brightness; };

layout(location = 0) in vec3 Position;
layout(location = 1) in vec3 Velocity;
layout(location = 2) in vec2 SpawnLife;
layout(location = 3) in vec4 Params;
layout(location = 4) in vec4 Color;
layout(location = 5) in ivec2 UV2;

layout(location = 0) out vec2 rayUV;
layout(location = 1) flat out vec4 rayColor;
layout(location = 2) out vec3 rayPosition;
layout(location = 3) flat out float rayPhase;

void main() {
    rayUV = vec2(0.0);
    rayColor = vec4(0.0);
    rayPosition = vec3(0.0);
    rayPhase = 0.0;
    gl_Position = vec4(-2.0, -2.0, -2.0, 1.0);
    float age = Time - SpawnLife.x;
    // A clipped quad runs no fragment shader and does not touch the framebuffer.
    if (SpawnLife.y <= 0.0 || age < 0.0 || age >= SpawnLife.y
        || daylight <= 0.0 || inWater <= 0.0 || brightness <= 0.0) return;
    vec3 axis = vec3(0.14, -1.0, 0.04);
    vec3 anchor = Position + Origin - axis * 8.0;
    float rayLength = clamp(Params.z, 0.1, 15.84);
    float closestDepth = clamp(-dot(anchor, axis) / dot(axis, axis), 0.0, rayLength);
    float distanceToAxis = length(anchor + axis * closestDepth);
    float insideFade = smoothstep(Params.x * 0.65, Params.x * 1.4 + 1.2, distanceToAxis);
    float fade = smoothstep(0.0, 40.0, age)
               * (1.0 - smoothstep(SpawnLife.y - 40.0, SpawnLife.y, age));
    if (insideFade <= 0.0 || fade <= 0.0 || Color.a <= 0.0
        || distanceToAxis - Params.x >= 44.0) return;

    int corner = gl_VertexIndex & 3;
    rayUV = vec2((corner == 1 || corner == 2) ? 1.0 : 0.0,
                 (corner >= 2) ? 0.0 : 1.0);
    // Trim negligible halo margins; keep original UV/world coordinates inside.
    float halfWidth = mix(0.90, 0.65, rayUV.y);
    rayUV.x = 0.5 + (rayUV.x - 0.5) * halfWidth;
    vec2 horizontal = -anchor.xz;
    float h = length(horizontal);
    vec3 right = h > 0.0001 ? vec3(horizontal.y, 0.0, -horizontal.x) / h
                           : vec3(1.0, 0.0, 0.0);
    vec3 vert = anchor + right * ((rayUV.x * 2.0 - 1.0) * Params.x)
                       + axis * (rayUV.y * rayLength);
    rayPosition = vert;
    rayPhase = Params.y * 6.2831853;
    rayColor = vec4(mix(Color.rgb, vec3(0.82, 0.94, 1.0), 0.50), Color.a * fade * insideFade);
    gl_Position = ProjMat * ModelViewMat * vec4(vert, 1.0);
}
