#version 330
#extension GL_ARB_separate_shader_objects : require

// Can't moj_import in things used during startup, when resource packs don't exist.
// This is a copy of dynamicimports.glsl
layout(std140) uniform DynamicTransforms {
    mat4 ModelViewMat;
    mat4 TextureMat;
    vec4 ColorModulator;
    vec3 ModelOffset;
};

uniform sampler2D Sampler0;

layout(location = 0) in vec2 texCoord0;
layout(location = 1) in vec4 vertexColor;

layout(location = 0) out vec4 fragColor;

layout(location = 2) in vec3 skyDirection;
layout(location = 3) flat in int endSkyGeometry;

const vec3 ORIGINAL_SKY_BACKGROUND = vec3(0.15, 0.0, 0.15);
const float STAR_STRENGTH = 0.42;
const float HORIZON_STRENGTH = 0.85;


float hash31(vec3 p) {
    p = fract(p * 0.1031);
    p += dot(p, p.yzx + 33.33);
    return fract((p.x + p.y) * p.z);
}

float starField(vec3 direction) {
    // Cubemap-style cells: no longitude seam or pinched poles.
    vec3 a = abs(direction);
    vec2 uv;
    float face;
    if (a.x >= a.y && a.x >= a.z) {
        uv = direction.yz / a.x;
        face = direction.x > 0.0 ? 1.0 : 2.0;
    } else if (a.y >= a.z) {
        uv = direction.xz / a.y;
        face = direction.y > 0.0 ? 3.0 : 4.0;
    } else {
        uv = direction.xy / a.z;
        face = direction.z > 0.0 ? 5.0 : 6.0;
    }
    vec2 grid = uv * 95.0;
    vec2 cell = floor(grid);
    float seed = hash31(vec3(cell, face * 29.0));
    vec2 center = vec2(
        hash31(vec3(cell, face * 31.0)),
        hash31(vec3(cell, face * 37.0))
    ) * 0.6 + 0.2;
    float radius = mix(0.045, 0.12, seed);
    float distanceToStar = length(fract(grid) - center);
    float aa = max(length(fwidth(grid)) * 0.32, 0.012);
    float point = 1.0 - smoothstep(max(0.0, radius - aa), radius + aa, distanceToStar);
    // Fade at face edges to avoid clipped dots along cube boundaries.
    float edgeFade = 1.0 - smoothstep(0.94, 1.0, max(abs(uv.x), abs(uv.y)));
    return point * step(0.9985, seed) * mix(0.35, 1.0, seed) * edgeFade;
}

void main() {
    vec4 texel = texture(Sampler0, texCoord0);
    // Also require the VFX+ End texture's magenta signature. Ordinary UI,
    // loading screens and textured geometry retain vanilla behaviour.
    if (endSkyGeometry == 0 || texel.g > 0.003922 || texel.r < 0.8 || texel.b < 0.99) {
        vec4 color = texel * vertexColor;
        if (color.a == 0.0) discard;
        fragColor = color * ColorModulator;
        return;
    }
    vec3 direction = normalize(skyDirection);
    float stars = starField(direction) * STAR_STRENGTH;

    // Reference direction: deep violet overhead, a wide violet glow at
    // the horizon and sparse small stars, without bright halos. This is sky
    // light only; the existing pack continues to control terrain fog.
    float horizon = exp(-pow(direction.y / 0.25, 2.0));
    float lowGlow = exp(-pow((direction.y + 0.10) / 0.36, 2.0));
    // Constant mean of TEST 04 modulation: no procedural cloud noise.
    const float variation = 0.97;
    vec3 violetBase = vec3(0.092, 0.008, 0.174);
    vec3 horizonColor = vec3(0.14, 0.030, 0.23) * horizon;
    horizonColor += vec3(0.045, 0.012, 0.065) * lowGlow;
    float lowerFade = mix(0.28, 1.0, smoothstep(-0.85, -0.18, direction.y));
    vec3 addition = violetBase + horizonColor * variation * HORIZON_STRENGTH;
    addition += stars * vec3(0.78, 0.62, 1.0);
    addition *= lowerFade;
    // Equivalent to TEST 06 background composition, before particles draw.
    vec3 oldBackground = texel.rgb * vertexColor.rgb * ColorModulator.rgb;
    vec3 retainedBackground = max(oldBackground - ORIGINAL_SKY_BACKGROUND, vec3(0.0));
    float threshold = fract(52.9829189 * fract(dot(gl_FragCoord.xy, vec2(0.06711056, 0.00583715))));
    float dither = (threshold - 0.5) / 255.0;
    fragColor = vec4(retainedBackground + addition + vec3(dither), 1.0);
}
