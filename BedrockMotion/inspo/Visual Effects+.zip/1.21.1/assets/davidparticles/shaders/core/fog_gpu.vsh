#version 150

#moj_import <fog.glsl>
#moj_import <light.glsl>

in vec3 Position;

uniform samplerBuffer ParticleData;
uniform sampler2D Sampler1;
uniform sampler2D Sampler2;

uniform mat4 ModelViewMat;
uniform mat4 ProjMat;
uniform int FogShape;

uniform vec3 Origin;
uniform float Time;
uniform float Aspect;
uniform int AreaCount;
uniform vec3 AreaSize;
uniform vec4 HeightmapInfo;
uniform float CameraY;

out float vertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;

const float PI = 3.14159265359;
const float TAU = 6.28318530718;

float hash(float seed, float salt) {
    return fract(sin(seed * 127.1 + salt * 311.7) * 43758.5453);
}

void hideParticle() {
    gl_Position = vec4(-2.0, -2.0, -2.0, 1.0);
    vertexDistance = 0.0;
    texCoord0 = vec2(0.0);
    vertexColor = vec4(0.0);
}

bool getSurfaceRelativeY(vec2 relativeXZ, out float surfaceRelativeY) {
    vec2 uv = (relativeXZ - HeightmapInfo.xy) / HeightmapInfo.z;
    if (any(lessThan(uv, vec2(0.0))) || any(greaterThanEqual(uv, vec2(1.0)))) {
        return false;
    }
    vec4 heightData = texelFetch(Sampler1, ivec2(uv * HeightmapInfo.z), 0);
    float surfaceWorldY = HeightmapInfo.w + heightData.r * 255.0 + heightData.g * 255.0 * 256.0;
    surfaceRelativeY = surfaceWorldY - CameraY;
    return true;
}

void main() {
    int quad = gl_VertexID >> 2;
    int corner = gl_VertexID & 3;
    int id = quad / AreaCount;
    int sub = quad - id * AreaCount;
    vec4 a = texelFetch(ParticleData, id * 4);
    vec4 b = texelFetch(ParticleData, id * 4 + 1);
    vec4 c = texelFetch(ParticleData, id * 4 + 2);
    vec4 d = texelFetch(ParticleData, id * 4 + 3);

    float life = b.w;
    float age = Time - b.z;
    if (life <= 0.0 || age < 0.0 || age >= life) {
        hideParticle();
        return;
    }

    float lifetimeProgress = age / life;
    float seed = c.x + float(sub) * 0.6180339;
    float lightAlpha = c.y;
    float size = c.w;
    float phase = d.y * TAU;

    float verticalOffset = (cos(phase) - cos(age * 0.04 + phase)) * 0.25;

    const float HEIGHT_ABOVE_SURFACE = 3.0;
    const float MAX_SURFACE_RISE = 4.0;

    vec3 particlePos = a.xyz + Origin;
    if (AreaCount > 1) {
        particlePos += (vec3(hash(seed, 5.0), hash(seed, 6.0), hash(seed, 7.0)) - 0.5) * AreaSize;
    }
    float emitterRelativeY = particlePos.y;

    float surfaceRelativeY;
    if (!getSurfaceRelativeY(particlePos.xz, surfaceRelativeY)) {
        hideParticle();
        return;
    }
    // not on trees, roofs and other surfaces well above the spawn height
    if (surfaceRelativeY > emitterRelativeY + MAX_SURFACE_RISE) {
        hideParticle();
        return;
    }
    particlePos.y = surfaceRelativeY + HEIGHT_ABOVE_SURFACE + verticalOffset;

    float distanceSquared = dot(particlePos, particlePos);
    if (distanceSquared > 900.0) {
        hideParticle();
        return;
    }
    float distanceToCamera = sqrt(distanceSquared);
    float innerDistanceFade = clamp((distanceSquared - 25.0) / 100.0, 0.0, 1.0);
    float outerDistanceFade = clamp((25.0 - distanceToCamera) / 5.0, 0.0, 1.0);
    float lifetimeFade = max(sin(PI * lifetimeProgress), 0.0);

    float alpha8 = floor(lightAlpha / 65536.0);
    float light = lightAlpha - alpha8 * 65536.0;
    float finalAlpha = alpha8 / 255.0 * lifetimeFade * innerDistanceFade * outerDistanceFade;

    vec3 right = vec3(ModelViewMat[0][0], ModelViewMat[1][0], ModelViewMat[2][0]);
    vec3 up = vec3(ModelViewMat[0][1], ModelViewMat[1][1], ModelViewMat[2][1]);

    vec2 cornerPosition = vec2((corner == 1 || corner == 2) ? 1.0 : -1.0, (corner >= 2) ? 1.0 : -1.0);
    float roll = phase + sin(age * 0.025 + phase) * 0.25;
    float rollSin = sin(roll);
    float rollCos = cos(roll);
    cornerPosition = vec2(cornerPosition.x * rollCos - cornerPosition.y * rollSin, cornerPosition.x * rollSin + cornerPosition.y * rollCos);

    vec3 renderPosition = particlePos + right * (cornerPosition.x * size) + up * (cornerPosition.y * size * Aspect);

    float u = (corner == 1 || corner == 2) ? 1.0 : 0.0;
    float v = (corner >= 2) ? 0.0 : 1.0;
    texCoord0 = vec2(u, v);

    // the fragment shader only uses the alpha, the colour comes from the fog
    ivec2 lightCoords = ivec2(int(mod(light, 256.0)), int(light / 256.0));
    vertexColor = vec4(1.0, 1.0, 1.0, finalAlpha) * minecraft_sample_lightmap(Sampler2, lightCoords);
    vertexDistance = fog_distance(renderPosition, FogShape);
    gl_Position = ProjMat * ModelViewMat * vec4(renderPosition, 1.0);
}
