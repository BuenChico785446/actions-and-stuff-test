#version 330
#extension GL_ARB_separate_shader_objects : require
uniform sampler2D InDepthSampler;
uniform sampler2D PreviousSampler;
layout(location = 0) in vec2 texCoord;
layout(location = 0) out vec4 fragColor;
layout(std140) uniform SamplerInfo {
    vec2 OutSize;
    vec2 InSize;
};
layout(std140) uniform PolyGlobals {
    mat4 PolyProjMat;
    mat4 PolyModelViewMat;
    float PolySunAngle;
    float PolyDayTime;
    float PolyDeltaTime;
};
layout(std140) uniform VfxFlareWeather { float flareWeather; };

// Two bytes avoid the convergence dead zone of an 8-bit exposure buffer.
vec2 packExposure(float value) {
    float code = floor(clamp(value, 0.0, 1.0) * 65535.0 + 0.5);
    return vec2(floor(code / 256.0), mod(code, 256.0)) / 255.0;
}
float unpackExposure(vec2 value) {
    return dot(floor(value * 255.0 + 0.5), vec2(256.0, 1.0)) / 65535.0;
}

// Sky is the cleared, exactly zero reversed-Z depth. A distant mountain is
// still geometry. Filter the binary sky mask, never the depth values.
float skyTexel(ivec2 p) {
    ivec2 size = textureSize(InDepthSampler, 0);
    if (any(lessThan(p, ivec2(0))) || any(greaterThanEqual(p, size))) return 0.0;
    return texelFetch(InDepthSampler, p, 0).r <= 0.0 ? 1.0 : 0.0;
}
float skyAt(vec2 uv) {
    vec2 p = uv * vec2(textureSize(InDepthSampler, 0)) - 0.5;
    ivec2 i = ivec2(floor(p));
    vec2 f = fract(p);
    return mix(mix(skyTexel(i), skyTexel(i + ivec2(1, 0)), f.x),
               mix(skyTexel(i + ivec2(0, 1)), skyTexel(i + ivec2(1, 1)), f.x), f.y);
}

void getLightWeights(float angle, out float sunWeight, out float moonWeight) {
    // A periodic altitude test also handles negative angles and the day wrap.
    sunWeight = smoothstep(-0.025, 0.075, -sin(angle));
    moonWeight = smoothstep(0.0, 0.10, sin(angle));
}

void main() {
    const float PI = 3.14159265359;
    const float HALF_CORE = 0.05;
    float angle = PolySunAngle + PI;
    vec3 direction = -vec3(cos(angle), sin(angle), 0.0);
    vec3 right = vec3(0.0, 0.0, 1.0);
    vec3 up = vec3(sin(angle), -cos(angle), 0.0);
    mat4 camera = PolyProjMat * PolyModelViewMat;
    vec4 center = camera * vec4(direction, 0.0);
    float target = 0.0;
    if (center.w > 0.0001) {
        vec2 lightUV = center.xy / center.w * 0.5 + 0.5;
        float screenFade = smoothstep(0.0, 0.10, lightUV.x)
            * smoothstep(0.0, 0.10, 1.0 - lightUV.x)
            * smoothstep(0.0, 0.12, lightUV.y)
            * smoothstep(0.0, 0.12, 1.0 - lightUV.y);
        if (screenFade > 0.0) {
            float visible = 0.0;
            // Stable 8x8 quadrature over the luminous core, in angular space.
            // Reproject every tap: resolution, FOV, aspect and perspective
            // cannot turn a nearby patch of open sky into a visible source.
            for (int y = 0; y < 8; ++y) {
                for (int x = 0; x < 8; ++x) {
                    vec2 q = (vec2(x, y) + 0.5) / 8.0 * 2.0 - 1.0;
                    vec4 tap = camera * vec4(direction + HALF_CORE * (right * q.x + up * q.y), 0.0);
                    if (tap.w > 0.0001) visible += skyAt(tap.xy / tap.w * 0.5 + 0.5);
                }
            }
            visible /= 64.0;
            // Tiny gaps do not light the entire lens. No max-of-taps test.
            visible *= smoothstep(0.02, 0.20, visible);
            float sunWeight, moonWeight;
            getLightWeights(PolySunAngle, sunWeight, moonWeight);
            float look = 1.0 - smoothstep(0.14, 0.78, distance(lightUV, vec2(0.5)));
            float weather = smoothstep(0.0, 1.0, clamp(flareWeather, 0.0, 1.0));
            target = visible * moonWeight * screenFade * look * weather;
        }
    }

    vec4 previous = texelFetch(PreviousSampler, ivec2(0), 0);
    bool valid = abs(previous.b - 94.0 / 255.0) < 0.001 && previous.a > 0.99;
    float oldValue = valid ? unpackExposure(previous.rg) : 0.0;
    // Polytone supplies game-time delta in ticks. Pausing freezes exposure.
    float dt = clamp(PolyDeltaTime * 0.05, 0.0, 0.1);
    float tau = target > oldValue ? 0.16 : 0.07;
    float value = mix(oldValue, target, 1.0 - exp(-dt / tau));
    // Strict occlusion wins over a temporal tail. Cap residual energy when
    // only a sliver is visible; never leave a flare through a closed wall.
    value = min(value, target * 1.5);
    if (target <= 0.00001) value = 0.0;
    fragColor = vec4(packExposure(value), 94.0 / 255.0, 1.0);
}
