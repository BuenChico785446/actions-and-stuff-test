package traben.entity_texture_features.mixin.mixins.entity.renderer.feature;

import net.minecraft.world.entity.LivingEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import traben.entity_texture_features.features.state.ETFState;
//#if MC >= 12103
import net.minecraft.client.renderer.entity.layers.WingsLayer;

@Mixin(WingsLayer.class)
public abstract class MixinElytraFeatureRenderer<T extends LivingEntity> {
//#else
//$$ import net.minecraft.client.renderer.entity.layers.ElytraLayer;
//$$ @Mixin(ElytraLayer.class)
//$$ public abstract class MixinElytraFeatureRenderer<T extends LivingEntity> {
//#endif

    @Inject(method =
            //#if MC >= 12109
            "submit(Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/SubmitNodeCollector;ILnet/minecraft/client/renderer/entity/state/HumanoidRenderState;FF)V"
            //#elseif MC >= 12103
            //$$ "render(Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource;ILnet/minecraft/client/renderer/entity/state/HumanoidRenderState;FF)V"
            //#else
            //$$ "render(Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource;ILnet/minecraft/world/entity/LivingEntity;FFFFFF)V"
            //#endif
            ,
            at = @At(value = "HEAD"))
    private void etf$markPatchable(CallbackInfo ci) {
        ETFState.allowTexturePatching = true;
    }

    @Inject(method =
            //#if MC >= 12109
            "submit(Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/SubmitNodeCollector;ILnet/minecraft/client/renderer/entity/state/HumanoidRenderState;FF)V"
            //#elseif MC >= 12103
            //$$ "render(Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource;ILnet/minecraft/client/renderer/entity/state/HumanoidRenderState;FF)V"
            //#else
            //$$ "render(Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource;ILnet/minecraft/world/entity/LivingEntity;FFFFFF)V"
            //#endif
            ,
            at = @At(value = "RETURN"))
    private void etf$markPatchableEnd(CallbackInfo ci) {
        ETFState.allowTexturePatching = false;
    }
}


