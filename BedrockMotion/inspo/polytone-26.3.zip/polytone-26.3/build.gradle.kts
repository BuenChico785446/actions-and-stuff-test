plugins {
    id("com.possible-triangle.core")
    id("com.possible-triangle.common") apply false
    id("com.possible-triangle.fabric") apply false
    id("com.possible-triangle.neoforge") apply false
    id("net.mehvahdjukaar.candlelight") version "1.2.4" apply false
}

mod {
    additional.add("mod_description")
    additional.add("mod_credits")
    additional.add("mod_license")
    additional.add("mod_homepage")
    additional.add("mod_authors")
    additional.add("mod_github")
    additional.add("nautilus_studio_version")
}


subprojects {

    apply(plugin = "com.possible-triangle.core")
    apply(plugin = "net.mehvahdjukaar.candlelight")
    // dev tool plugin; skipped on machines that don't have it
    runCatching { apply(plugin = "dev.mixinmcp.decompile") }

    dependencies {
        compileOnly("net.mehvahdjukaar:candlelight:1.2.4")
    }

    //sodium shenanigans
    val sodium_neoforge_version: String by rootProject.extra
    val sodiumDist = configurations.create("sodiumDist") { isTransitive = false }
    dependencies {
        add("sodiumDist", "maven.modrinth:sodium:$sodium_neoforge_version")
    }
    tasks.register<Copy>("extractSodiumNeoforge") {
        from({ zipTree(sodiumDist.singleFile).matching { include("META-INF/jarjar/*-mod.jar") } })
        into(layout.buildDirectory.dir("sodium"))
        eachFile { path = "sodium-neoforge-mod.jar" }
        includeEmptyDirs = false
    }

    repositories {
        nexus()
    }

    upload {
        maven {
            nexus()
        }
        curseforge {
            dependencies {
            }
        }
        modrinth {
            dependencies {
            }
        }

        forEach {
            changelog = rootProject.file("changelog.md").readText()
            versionName = "${mod.id.get()}-${mod.version.get()}-${project.name}"
        }
    }

    tasks.processResources {
        from(rootDir) {
            include("MVEL_LICENSE.md")
            into("") // root of jar (or change path below)
        }
    }

    tasks.withType<JavaCompile> {
        options.compilerArgs.addAll(listOf("-Xmaxerrs", "4000"))
        options.release.set(25)
    }

    configure<JavaPluginExtension> {
        sourceCompatibility = JavaVersion.VERSION_25
        targetCompatibility = JavaVersion.VERSION_25
    }

    repositories {
        // Standard repositories
        mavenLocal()
        mavenCentral()

        flatDir {
            dirs("mods")
        }

        maven { url = uri("https://jitpack.io") }

        maven { url = uri("https://maven.neoforged.net/releases") }
        maven { url = uri("https://maven.architectury.dev") }
        maven { url = uri("https://maven.parchmentmc.org") }

        maven { url = uri("https://maven.createmod.net") } // Create Mod, Ponder, Flywheel
        maven { url = uri("https://maven.blamejared.com") } // JEI, Vazkii's Mods
        maven { url = uri("https://maven.ladysnake.org/releases") } // Ladysnake mods
        // maven { url = uri("https://maven.tterrag.com/") } // Flywheel, EnderIO - host unreachable, hangs mod-dep resolution; re-enable if a dep needs it
        maven { url = uri("https://mvn.devos.one/releases/") } // Registrate, Porting Lib (releases)
        maven { url = uri("https://mvn.devos.one/snapshots/") } // Registrate, Porting Lib (snapshots)
        maven { url = uri("https://maven.saps.dev/releases") } // FTB Mods
        maven { url = uri("https://dl.cloudsmith.io/public/tslat/sbl/maven/") }
        maven { url = uri("https://maven.theillusivec4.top/") } // Curios API
        maven { url = uri("https://maven.squiddev.cc") } // CC: Tweaked
        maven { url = uri("https://maven.su5ed.dev/releases") } // SU5ED mods
        maven { url = uri("https://harleyoconnor.com/maven") } // Dynamic Trees
        maven { url = uri("https://maven.misterpemodder.com/libs-release/") } // ShulkerBoxTooltip
        maven { url = uri("https://maven.firstdarkdev.xyz/snapshots") } // FirstDarkDev (snapshots)
        maven { url = uri("https://raw.githubusercontent.com/Fuzss/modresources/main/maven") } // Fuzss' Mod Resources
        maven { url = uri("https://maven.jamieswhiteshirt.com/libs-release") } // Jamie's Mods
        maven { url = uri("https://raw.githubusercontent.com/fishstiz/maven/m2") } // Packed Packs (api)
    }
}
