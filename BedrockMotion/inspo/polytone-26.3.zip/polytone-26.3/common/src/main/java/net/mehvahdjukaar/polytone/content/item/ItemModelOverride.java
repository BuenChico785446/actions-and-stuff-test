package net.mehvahdjukaar.polytone.content.item;

public class ItemModelOverride {
    /*
    @Nullable
    protected final Dynamic<?> lazyComponent;
    @Nullable
    protected final Integer stackCount;
    @Nullable
    protected final Pattern pattern;
    @Nullable
    protected final CompoundTag entityTag;
    @Nullable
    protected final ColormapExpressionProvider expression;
    protected ModelResourceLocation model;
    protected DataComponentMap decodedComponents;
    protected Map<DataComponentType<?>, CompoundTag> nbtMatchers;

    protected static final Codec<Map<Identifier, Float>> ITEM_PREDICATE_CODEC = Codec.unboundedMap(Identifier.CODEC, Codec.FLOAT);

    protected static final UnboundedMapCodec<DataComponentType<?>, CompoundTag> NBT_COMPONENTS_CODEC = Codec.unboundedMap(DataComponentType.CODEC, CompoundTag.CODEC);

    public static final Codec<ItemModelOverride> CODEC = RecordCodecBuilder.create(instance -> instance.group(
            Codec.PASSTHROUGH.optionalFieldOf("components").forGetter(o ->  Optional.ofNullable(o.lazyComponent)),
            ModelResHelper.MODEL_RES_CODEC.fieldOf("model").forGetter(ItemModelOverride::model),
            Codec.INT.optionalFieldOf("stack_count").forGetter(i -> Optional.ofNullable(i.stackCount())),
            ExtraCodecs.PATTERN.optionalFieldOf("name_pattern").forGetter(i -> Optional.ofNullable(i.namePattern())),
            CompoundTag.CODEC.optionalFieldOf("entity_nbt").forGetter(i -> Optional.ofNullable(i.entityTag)),
            ColormapExpressionProvider.CODEC.optionalFieldOf("expression").forGetter(i -> Optional.ofNullable(i.expression)),
            NBT_COMPONENTS_CODEC.optionalFieldOf("item_nbt_components", Map.of()).forGetter(i -> i.nbtMatchers)
    ).apply(instance, ItemModelOverride::new));

    public static final Codec<Partial> CODEC_MODEL_ONLY = RecordCodecBuilder.create(instance -> instance.group(
            ModelResHelper.MODEL_RES_CODEC.fieldOf("model").forGetter(Partial::model)
    ).apply(instance, Partial::new));

    public record Partial(ModelResourceLocation model) {
    }

    public ItemModelOverride(Optional<Dynamic<?>> lazyComponent, ModelResourceLocation model, Optional<Integer> stackCount,
                             Optional<Pattern> pattern, Optional<CompoundTag> entityTag,
                             Optional<ColormapExpressionProvider> expression,
                             Map<DataComponentType<?>,CompoundTag> nbtMatchers) {
        this.lazyComponent = lazyComponent.orElse(null);
        this.model = model;
        this.stackCount = stackCount.orElse(null);
        this.pattern = pattern.orElse(null);
        this.entityTag = entityTag.orElse(null);
        this.expression = expression.orElse(null);
        this.nbtMatchers = nbtMatchers;
    }

    public ItemModelOverride(DataComponentMap map, ModelResourceLocation model) {
        this.lazyComponent = null;
        this.model = model;
        this.stackCount = null;
        this.pattern = null;
        this.decodedComponents = map;
        this.entityTag = null;
        this.expression = null;
    }


    public DataComponentMap getComponents(HolderLookup.Provider registryAccess) {
        if (this.decodedComponents == null && this.lazyComponent != null) {
            this.decodedComponents = runCodec(registryAccess, this.lazyComponent);
        }
        return this.decodedComponents;
    }

    private static <T> DataComponentMap runCodec(HolderLookup.Provider ra, Dynamic<T> dynamic) {
        DynamicOps<T> ops = RegistryOps.create(dynamic.getOps(), ra);
        return DataComponentMap.CODEC.decode(ops, dynamic.getValue())
                .result().orElseThrow(() -> new JsonParseException("Failed to decode components map"))
                .getFirst();
    }

    public ModelResourceLocation model() {
        return this.model;
    }

    @Nullable
    public Integer stackCount() {
        return this.stackCount;
    }

    @Nullable
    public Pattern namePattern() {
        return this.pattern;
    }

    @Nullable
    public CompoundTag entityTag() {
        return this.entityTag;
    }


    public boolean matchesPredicate(ItemStack stack, @Nullable Level level, @Nullable Supplier<CompoundTag> entityTagGetter,
                                    @Nullable Component customName) {
        if (this.pattern != null && customName != null) {
            if (!this.pattern.matcher(customName.getString()).matches()) return false;
        }

        if (this.entityTag != null && entityTagGetter != null) {
            CompoundTag tag = entityTagGetter.get();
            if (!containsTag(tag, this.entityTag)) return false;
        }
        if (this.expression != null) {
            BlockPos pos = ClientFrameTicker.getCameraPos();
            if (this.expression.getValue(null, pos, null, null, stack) == 0) return false;
        }

        for (var m : this.nbtMatchers.entrySet()) {
            var type = m.getKey();
            var c = stack.get(type);
            if (c instanceof CustomData d) {
                if (!containsTag(d.getUnsafe(), m.getValue())) return false;
            }
        }

        return true;
    }

    private static boolean containsTag(CompoundTag tagToMatch, CompoundTag entityTag) {
        for (String key : tagToMatch.getAllKeys()) {
            Tag t = entityTag.get(key);
            if (t == null) return false;
            if (t instanceof CompoundTag ct) {
                CompoundTag compound = tagToMatch.getCompound(key);
                if (compound.isEmpty()) return false;
                if (!containsTag(compound, ct)) return false;
            } else if (!t.equals(entityTag.get(key))) return false;
        }
        return true;
    }
*/
}
