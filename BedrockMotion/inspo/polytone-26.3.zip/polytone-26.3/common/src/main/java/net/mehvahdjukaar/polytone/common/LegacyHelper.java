package net.mehvahdjukaar.polytone.common;

import com.google.common.collect.LinkedListMultimap;
import com.mojang.serialization.Codec;
import com.mojang.serialization.Decoder;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import it.unimi.dsi.fastutil.objects.Object2IntMap;
import it.unimi.dsi.fastutil.objects.Object2IntOpenHashMap;
import it.unimi.dsi.fastutil.objects.Object2ObjectOpenHashMap;
import net.mehvahdjukaar.polytone.PlatStuff;
import net.mehvahdjukaar.polytone.Polytone;
import net.mehvahdjukaar.polytone.common.expressions.impl.IColormapExp;
import net.mehvahdjukaar.polytone.common.struc.ArrayImage;
import net.mehvahdjukaar.polytone.content.biome.BiomeIdMapper;
import net.mehvahdjukaar.polytone.content.biome.BiomeKeysCache;
import net.mehvahdjukaar.polytone.content.block.BlockPropertyModifier;
import net.mehvahdjukaar.polytone.content.colormap.Colormap;
import net.mehvahdjukaar.polytone.content.fluid.FluidPropertyModifier;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier;
import net.minecraft.tags.TagKey;
import net.minecraft.resources.ResourceKey;
import net.minecraft.util.Util;
import net.minecraft.world.item.ItemStack;
import net.minecraft.client.renderer.block.BlockAndTintGetter;
import net.minecraft.world.level.biome.Biome;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.RedstoneWireBlock;
import net.minecraft.world.level.block.StemBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.*;
import java.util.regex.Pattern;

public class LegacyHelper {

    private static final Map<String, String> PATHS = Util.make(new Object2ObjectOpenHashMap<>(), m -> {
                m.put("world0", "overworld");
                m.put("world0_thunder", "overworld_thunder");
                m.put("world0_rain", "overworld_rain");
                m.put("world1", "the_end");
                m.put("world-1", "the_nether");
                m.put("pine", "spruce_leaves");
                m.put("birch", "birch_leaves");
                m.put("redstone", "redstone_wire");
                m.put("pumpkinstem", "pumpkin_stem");
                m.put("melonstem", "melon_stem");
                m.put("underwater", "water_fog");
            }
    );

    public static <T> Map<Identifier, T> convertPaths(Map<Identifier, T> map) {
        Map<Identifier, T> toUpdate = new HashMap<>();
        List<Identifier> toRemove = new ArrayList<>();
        for (var entry : map.entrySet()) {
            Identifier id = entry.getKey();
            Identifier newPath = convertPath(id);
            if (!newPath.equals(id)) {
                toUpdate.put(newPath, entry.getValue());
                toRemove.add(id);
            }
        }
        toRemove.forEach(map.keySet()::remove);
        map.putAll(toUpdate);
        return map;
    }

    public static Identifier convertPath(Identifier id) {
        String path = PATHS.get(id.getPath());
        return path == null ? id : id.withPath(path);
    }


    public static Map<Identifier, Parsed<BlockPropertyModifier>> convertBlockProperties(
            Map<Identifier, Properties> ofProperties, Map<Identifier, ArrayImage> textures) {

        List<Identifier> ids = new ArrayList<>();
        ids.addAll(ofProperties.keySet());
        ids.addAll(textures.keySet());

        Map<Identifier, Parsed<BlockPropertyModifier>> map = new HashMap<>();

        for (Identifier id : ids) {
            @Nullable Properties prop = ofProperties.get(id);
            String path = id.getPath();

            // hardcoded special color stuff
            if (path.equals("stem") || path.equals("melon_stem") || path.equals("pumpkin_stem")) {
                Colormap colormap = Colormap.simple(new IColormapExp() {
                    @Override
                    public float evaluate(@NotNull BlockAndTintGetter level, @Nullable BlockState state, Vec3 pos, Biome biome, BiomeIdMapper mapper, ItemStack stack) {
                        return state != null && state.hasProperty(StemBlock.AGE) ? state.getValue(StemBlock.AGE) / 7f : 0;
                    }

                    @Override
                    public boolean usesBiome() {
                        return false;
                    }

                    @Override
                    public boolean usesPos() {
                        return false;
                    }
                }, IColormapExp.ZERO);

                List<Block> targets = new ArrayList<>();
                // so stem maps to both
                if (!path.contains("melon")) {
                    targets.add(Blocks.PUMPKIN_STEM);
                    targets.add(Blocks.ATTACHED_PUMPKIN_STEM);
                }
                if (!path.contains("pumpkin")) {
                    targets.add(Blocks.MELON_STEM);
                    targets.add(Blocks.ATTACHED_MELON_STEM);
                }
                map.put(id, withCond(id, prop, BlockPropertyModifier.coloringBlocks(colormap, targets)));
            } else if (path.equals("redstone_wire")) {
                Colormap colormap = Colormap.simple(new IColormapExp() {
                    @Override
                    public float evaluate(@NotNull BlockAndTintGetter level, @Nullable BlockState state, Vec3 pos, Biome biome, BiomeIdMapper mapper, ItemStack stack) {
                        return state != null ? (1 - (state.getValue(RedstoneWireBlock.POWER) / 15f)) : 1;
                    }

                    @Override
                    public boolean usesBiome() {
                        return false;
                    }

                    @Override
                    public boolean usesPos() {
                        return false;
                    }
                }, IColormapExp.ZERO);

                map.put(id, withCond(id, prop, BlockPropertyModifier.coloringBlocks(colormap, Blocks.REDSTONE_WIRE)));
            } else if (prop != null) {
                try {
                    BlockPropertyModifier modifier = convertOFProperty(prop, id);
                    map.put(id, withCond(id, prop, modifier));
                } catch (Exception e) {
                    Polytone.LOGGER.error("FAILED TO CONVERT OPTIFINE COLORMAP AT {}. Its likely the file has errors: ", id, e);
                }
            }
        }
        return map;

    }

    private static <T> Parsed<T> withCond(Identifier id, @Nullable Properties prop, T t) {
        return Parsed.lowPriority(t, id, prop == null || checkConditions(prop));
    }

    private static boolean checkConditions(Properties prop) {
        boolean ignored = prop.getOrDefault("polytone_ignore", false).equals("true");
        if (ignored) {
            return false;
        }
        List<String> requireMods = List.of(prop.getProperty("require_mods", "").split(" "));
        for (String s : requireMods) {
            if (!s.isEmpty() && !PlatStuff.isModLoaded(s)) {
                return false;
            }
        }
        return true;
    }

    public static final Decoder<BlockPropertyModifier> OF_JSON_CODEC = RecordCodecBuilder.create(i -> i.group(
            Codec.STRING.optionalFieldOf("format", "").forGetter(c -> ""),
            Codec.STRING.listOf().optionalFieldOf("blocks", List.of()).forGetter(c -> List.of()),
            ColorUtils.COLOR.optionalFieldOf("color").forGetter(c -> Optional.empty()),
            Codec.STRING.xmap(Integer::parseInt, String::valueOf).optionalFieldOf("yVariance").forGetter(c -> Optional.empty()),
            Codec.STRING.xmap(Integer::parseInt, String::valueOf).optionalFieldOf("yoffset").forGetter(c -> Optional.empty()),
            Codec.STRING.optionalFieldOf("source").forGetter(c -> Optional.empty()),
            Codec.BOOL.optionalFieldOf("force_tint", true).forGetter(c -> true)
    ).apply(i, LegacyHelper::decodeOFPropertyJson));

    private static BlockPropertyModifier decodeOFPropertyJson(String format, List<String> targets,
                                                              Optional<Integer> singleColor, Optional<Integer> yVariance,
                                                              Optional<Integer> yoffset, Optional<String> sourceTexture,
                                                              boolean forceTint) {

        List<String> names = List.of();
        Colormap colormap;
        if (!targets.isEmpty()) {
            names = targets.stream()
                    .filter(s -> {
                        // fuck this i wont parse numerical shit
                        try {
                            int iHateOptishit = Integer.parseInt(s);
                            // return BuiltInRegistries.BLOCK.getKey(BuiltInRegistries.BLOCK.byId(iHateOptishit));
                            return false;
                        } catch (Exception ignored) {
                        }
                        return true;
                    }).toList();
            if (forceTint) names.forEach(LegacyHelper::forceBlockToHaveTintIndex);

        }
        Integer col = singleColor.orElse(null);
        if ("fixed".equals(format)) {
            colormap = Colormap.createFixed();
        } else if ("grid".equals(format)) {
            colormap = Colormap.createBiomeId();
            //variance and y offset are ignored. todo: add
        } else {
            colormap = Colormap.createDefTriangle();
        }
        if (col != null) {
            int[][] matrix = {{col}};
            colormap.acceptTexture(new ArrayImage(matrix));
        } else {
            if (sourceTexture.isPresent()) {

                // assumes id is minecraft. Not ideal.. too bad
                Identifier id = Identifier.parse("none");
                String source = sourceTexture.get().replace("~/colormap/", id.getNamespace() + ":");
                if (source.contains("./")) {
                    // resolve relative paths
                    String directoryPath = StrUtils.directoryOf(id.getPath());
                    source = source.replace("./", id.getNamespace() + ":" + directoryPath);
                }
                colormap.setExplicitTargetTexture(Identifier.parse(source));
            }
        }
        return new BlockPropertyModifier(Optional.of(colormap),
                Optional.empty(), Optional.empty(),
                Optional.empty(), Optional.empty(),
                Optional.empty(), Optional.empty(),
                Optional.empty(), List.of(), List.of(),
                Optional.empty(), Optional.empty(),
                false, Targets.legacyIds(names), false);
    }


    public static BlockPropertyModifier convertOFProperty(Properties properties, Identifier id) {
        Targets targets = Targets.EMPTY;
        Colormap colormap;
        boolean forceTint = Boolean.parseBoolean(properties.getProperty("force_tint", "true"));
        var blockList = properties.getProperty("blocks");
        if (blockList != null) {
            List<String> names = Arrays.stream(blockList.split(" "))
                    .filter(s -> {
                        if (s.isEmpty()) return false;
                        // fuck this i wont parse numerical shit
                        try {
                            int iHateOptishit = Integer.parseInt(s);
                            // return BuiltInRegistries.BLOCK.getKey(BuiltInRegistries.BLOCK.byId(iHateOptishit));
                            return false;
                        } catch (Exception ignored) {
                        }
                        return true;
                    }).toList();
            targets = Targets.legacyIds(names);
            if (forceTint) names.forEach(LegacyHelper::forceBlockToHaveTintIndex);
        }

        String format = properties.getProperty("format");
        Integer col = null;
        String singleColor = properties.getProperty("color");
        if (singleColor != null) {
            col = Integer.parseInt(singleColor, 16);
        }
        if ("fixed".equals(format)) {
            colormap = Colormap.createFixed();
        } else if ("grid".equals(format)) {
            colormap = Colormap.createBiomeId();
            //variance and y offset are ignored. todo: add
        } else {
            colormap = Colormap.createDefTriangle();
        }
        if (col != null) {
            int[][] matrix = {{col}};
            colormap.acceptTexture(new ArrayImage(matrix));
        } else {
            String source = properties.getProperty("source");
            if (source != null) {
                if (source.contains("~")) {
                    source = source.replace("~/colormap/", id.getNamespace() + ":");
                } else {
                    // resolve relative paths
                    String directoryPath = StrUtils.directoryOf(id.getPath());
                    source = (id.getNamespace() + ":" + directoryPath) + source.replace("./", "");
                }
                colormap.setExplicitTargetTexture(Identifier.parse(source));
            }
        }
        return new BlockPropertyModifier(Optional.of(colormap),
                Optional.empty(), Optional.empty(),
                Optional.empty(), Optional.empty(),
                Optional.empty(), Optional.empty(), Optional.empty(),
                List.of(), List.of(), Optional.empty(),
                Optional.empty(), false, targets, false);
    }

    public static Map<Identifier, Parsed<BlockPropertyModifier>> convertInlinedPalettes(
            Map<Identifier, String> inlineColormaps) {
        Map<Identifier, Parsed<BlockPropertyModifier>> map = new HashMap<>();

        int k = 0;
        for (var special : inlineColormaps.entrySet()) {
            Identifier texturePath = special.getKey();
            Colormap colormap = Colormap.createDefTriangle();
            colormap.setExplicitTargetTexture(texturePath);

            List<String> names = new ArrayList<>();
            for (var name : special.getValue().split(" ")) {
                if (name.isEmpty()) continue;
                names.add(name);
                forceBlockToHaveTintIndex(name);
            }
            if (!names.isEmpty()) {
                BlockPropertyModifier mod = BlockPropertyModifier.coloringBlocks(colormap, Targets.legacyIds(names));

                // unique id just because
                Identifier id = texturePath.withSuffix("-color_prop_palette_" + k++);
                map.put(id, Parsed.success(mod, id));
            }
        }
        return map;
    }

    private static void forceBlockToHaveTintIndex(String name) {
        if (name.startsWith("#")) {
            Identifier tagId = Identifier.tryParse(name.substring(1));
            if (tagId == null) return;
            for (var holder : BuiltInRegistries.BLOCK.getTagOrEmpty(TagKey.create(Registries.BLOCK, tagId))) {
                forceBlockToHaveTintIndex(holder.value());
            }
        } else {
            Identifier blockId = Identifier.tryParse(name);
            Block b = blockId == null ? null : BuiltInRegistries.BLOCK.getOptional(blockId).orElse(null);
            if (b != null) forceBlockToHaveTintIndex(b);
        }
    }

    private static void forceBlockToHaveTintIndex(Block block) {
        if (block != Blocks.REDSTONE_WIRE && block != Blocks.PUMPKIN_STEM && block != Blocks.MELON_STEM) {
            //Polytone.VARIANT_TEXTURES.addTintOverrideHack(block);
        }
    }

    public static int getBiomeId(Biome biome) {
        return BIOME_ID_MAP.getOrDefault(BiomeKeysCache.get(biome), 0);
    }

    //whateve optifine uses...
    private static final Object2IntMap<ResourceKey<Biome>> BIOME_ID_MAP = Util.make(() -> {
        Object2IntMap<ResourceKey<Biome>> map = new Object2IntOpenHashMap<>();
        // Add entries to the map
        map.put(biomeResKey("the_void"), 0);
        map.put(biomeResKey("plains"), 1);
        map.put(biomeResKey("sunflower_plains"), 2);
        map.put(biomeResKey("snowy_plains"), 3);
        map.put(biomeResKey("ice_spikes"), 4);
        map.put(biomeResKey("desert"), 5);
        map.put(biomeResKey("swamp"), 6);
        map.put(biomeResKey("mangrove_swamp"), 7);
        map.put(biomeResKey("forest"), 8);
        map.put(biomeResKey("flower_forest"), 9);
        map.put(biomeResKey("birch_forest"), 10);
        map.put(biomeResKey("dark_forest"), 11);
        map.put(biomeResKey("old_growth_birch_forest"), 12);
        map.put(biomeResKey("old_growth_pine_taiga"), 13);
        map.put(biomeResKey("old_growth_spruce_taiga"), 14);
        map.put(biomeResKey("taiga"), 15);
        map.put(biomeResKey("snowy_taiga"), 16);
        map.put(biomeResKey("savanna"), 17);
        map.put(biomeResKey("savanna_plateau"), 18);
        map.put(biomeResKey("windswept_hills"), 19);
        map.put(biomeResKey("windswept_gravelly_hills"), 20);
        map.put(biomeResKey("windswept_forest"), 21);
        map.put(biomeResKey("windswept_savanna"), 22);
        map.put(biomeResKey("jungle"), 23);
        map.put(biomeResKey("sparse_jungle"), 24);
        map.put(biomeResKey("bamboo_jungle"), 25);
        map.put(biomeResKey("badlands"), 26);
        map.put(biomeResKey("eroded_badlands"), 27);
        map.put(biomeResKey("wooded_badlands"), 28);
        map.put(biomeResKey("meadow"), 29);
        map.put(biomeResKey("cherry_grove"), 30);
        map.put(biomeResKey("grove"), 31);
        map.put(biomeResKey("snowy_slopes"), 32);
        map.put(biomeResKey("frozen_peaks"), 33);
        map.put(biomeResKey("jagged_peaks"), 34);
        map.put(biomeResKey("stony_peaks"), 35);
        map.put(biomeResKey("river"), 36);
        map.put(biomeResKey("frozen_river"), 37);
        map.put(biomeResKey("beach"), 38);
        map.put(biomeResKey("snowy_beach"), 39);
        map.put(biomeResKey("stony_shore"), 40);
        map.put(biomeResKey("warm_ocean"), 41);
        map.put(biomeResKey("lukewarm_ocean"), 42);
        map.put(biomeResKey("deep_lukewarm_ocean"), 43);
        map.put(biomeResKey("ocean"), 44);
        map.put(biomeResKey("deep_ocean"), 45);
        map.put(biomeResKey("cold_ocean"), 46);
        map.put(biomeResKey("deep_cold_ocean"), 47);
        map.put(biomeResKey("frozen_ocean"), 48);
        map.put(biomeResKey("deep_frozen_ocean"), 49);
        map.put(biomeResKey("mushroom_fields"), 50);
        map.put(biomeResKey("dripstone_caves"), 51);
        map.put(biomeResKey("lush_caves"), 52);
        map.put(biomeResKey("deep_dark"), 53);
        map.put(biomeResKey("nether_wastes"), 54);
        map.put(biomeResKey("warped_forest"), 55);
        map.put(biomeResKey("crimson_forest"), 56);
        map.put(biomeResKey("soul_sand_valley"), 57);
        map.put(biomeResKey("basalt_deltas"), 58);
        map.put(biomeResKey("the_end"), 59);
        map.put(biomeResKey("end_highlands"), 60);
        map.put(biomeResKey("end_midlands"), 61);
        map.put(biomeResKey("small_end_islands"), 62);
        map.put(biomeResKey("end_barrens"), 63);
        map.put(biomeResKey("pale_garden"), 64);
        return map;
    });

    private static ResourceKey<Biome> biomeResKey(String endBarrens) {
        return ResourceKey.create(Registries.BIOME, Identifier.parse(endBarrens));
    }


    public static void convertOfBlockToFluidProp(LinkedListMultimap<Identifier, Parsed<BlockPropertyModifier>> parsedModifiers,
                                                 Map<Identifier, ArrayImage> textures) {
        if (!Polytone.CONFIGS.legacyParsing.get()) return;

        Map<Identifier, Parsed<BlockPropertyModifier>> fluid = new HashMap<>();
        Map<Identifier, Parsed<BlockPropertyModifier>> fog = new HashMap<>();
        Map<Identifier, ArrayImage> filteredTextures = new HashMap<>();
        for (var entry : parsedModifiers.entries()) {
            Identifier id = entry.getKey();
            Parsed<BlockPropertyModifier> parsed = entry.getValue();
            BlockPropertyModifier modifier = parsed.getResultOrPartial();
            var colormap = modifier.getColormap();
            if (colormap instanceof Colormap c) {
                //  if (!id.getNamespace().equals("minecraft")) continue;
                String path = id.getPath();
                if (path.contains("water") || path.contains("lava")) {

                    //remove custom
                    if (path.contains("/")) {
                        id = id.withPath(path.substring(path.lastIndexOf('/') + 1));
                    }
                    if (path.endsWith("_fog") || path.contains("under")) fog.put(id, parsed);
                    else fluid.put(id, parsed);

                    Identifier targetTexture = c.getTargetTexture(id);
                    //uglyyy
                    c.setExplicitTargetTexture(LegacyHelper.convertPath(targetTexture));
                    if (textures.containsKey(targetTexture)) {
                        filteredTextures.put(targetTexture, textures.get(targetTexture));
                    }
                }
            }
        }
        for (var v : textures.entrySet()) {
            Identifier id = v.getKey();
            if (id.getNamespace().equals("minecraft") && (id.getPath().contains("water") || id.getPath().contains("lava"))) {
                filteredTextures.put(id, v.getValue());
            }
        }

        parsedModifiers.keySet().removeAll(fluid.keySet());

        Map<Identifier, Parsed<FluidPropertyModifier>> converted = new HashMap<>();

        for (var f : fluid.entrySet()) {
            // ignore targets as those are block targets anyways
            var parsed = f.getValue();

            var mod = parsed.getResultOrPartial();
            Identifier id = f.getKey();
            Targets targets = mod.targets().merge(Targets.ofIds(id, id.withPrefix("flowing_")));
            var fogMod = Optional.ofNullable(fog.get(id.withSuffix("_fog")))
                    .map(Parsed::getResultOrPartial);
            FluidPropertyModifier modifier = new FluidPropertyModifier(mod.tintGetter(),
                    fogMod.map(BlockPropertyModifier::getColormap),
                    Optional.empty(), Optional.empty(),
                    targets);
            var parsedModifier = Parsed.lowPriority(modifier, id, parsed.isEnabled());
            converted.put(id, parsedModifier);
        }

        Polytone.FLUID_MODIFIERS.addConvertedBlockProperties(converted, filteredTextures);
    }

    public static void convertOfBlockToDimensionProperties(LinkedListMultimap<Identifier, Parsed<BlockPropertyModifier>> parsedModifiers,
                                                           Map<Identifier, ArrayImage> textures) {
        if (!Polytone.CONFIGS.legacyParsing.get()) return;

        Map<Identifier, Parsed<BlockPropertyModifier>> filtered = new HashMap<>();
        Map<Identifier, ArrayImage> filteredTextures = new HashMap<>();
        Pattern fogP = Pattern.compile("minecraft:(?:fog|fogcolor)[0-2]\\b");
        Pattern skyP = Pattern.compile("minecraft:(?:sky|skycolor)[0-2]\\b");
        for (var entry : parsedModifiers.entries()) {
            Identifier id = entry.getKey();
            String stringId = id.toString();
            var modifier = entry.getValue();
            if (fogP.matcher(stringId).matches() || skyP.matcher(stringId).matches()) {
                filtered.put(id, modifier);
            }
        }
        for (var entry : textures.entrySet()) {
            Identifier id = entry.getKey();
            String stringId = id.toString();
            ArrayImage modifier = entry.getValue();
            if (fogP.matcher(stringId).matches() || skyP.matcher(stringId).matches()) {
                filteredTextures.put(id, modifier);
            }
        }
        parsedModifiers.keySet().removeAll(filtered.keySet());

        addConvertedBlockProperties(filtered, filteredTextures);

    }

    //TODO: add back
    // for OF fog and sky. shit code...
    private static void addConvertedBlockProperties(Map<Identifier, Parsed<BlockPropertyModifier>> modifiers, Map<Identifier, ArrayImage> textures) {
//        String[] names = new String[]{"overworld", "the_nether", "the_end"};
//        Map<Identifier, Parsed<DimensionEffectsModifier>> converted = new HashMap<>();
//        for (int i = 0; i <= 2; i++) {
//            IColorGetter skyCol;
//            IColorGetter fogCol;
//            boolean skyEnabled;
//            boolean fogEnabled;
//            {
//                Identifier skyKey = Identifier.parse("sky" + i);
//                Identifier skyKey2 = Identifier.parse("skycolor" + i);
//                var skyMod = modifiers.get(skyKey);
//                if (skyMod == null){
//                    skyMod = modifiers.get(skyKey2);
//                    skyKey = skyKey2;
//                }
//                ArrayImage skyImage = textures.get(skyKey);
//
//                skyCol = skyMod != null ? skyMod.getResultOrPartial().getColormap() : (skyImage == null ? null : Colormap.createDefTriangle());
//                if (skyCol != null) {
//                    ColormapsManager.tryAcceptingTexture(textures, skyKey, skyCol, new HashSet<>(), true);
//                }
//                skyEnabled = skyMod == null || skyMod.isEnabled();
//            }
//            {
//                Identifier fogKey = Identifier.parse("fog" + i);
//                Identifier fogKey2 = Identifier.parse("fogcolor" + i);
//                var fogMod = modifiers.get(fogKey);
//                if (fogMod == null){
//                    fogMod = modifiers.get(fogKey2);
//                    fogKey = fogKey2;
//                }
//                ArrayImage fogImage = textures.get(fogKey);
//
//                fogCol = fogMod != null ? fogMod.getResultOrPartial().getColormap() : (fogImage == null ? null : Colormap.createDefTriangle());
//                if (fogCol != null) {
//                    ColormapsManager.tryAcceptingTexture(textures, fogKey, fogCol, new HashSet<>(), true);
//                }
//                fogEnabled = fogMod == null || fogMod.isEnabled();
//            }
//            if (fogCol != null || skyCol != null) {
//                var mod = new DimensionEffectsModifier(Optional.empty(), Optional.empty(),
//                        Optional.empty(), Optional.empty(), Optional.empty(),
//                        Optional.ofNullable(fogCol), Optional.empty(), Optional.ofNullable(skyCol), Optional.empty(),
//                        false, false, Optional.empty(), DimensionTarget.EMPTY);
//
//                Identifier id = Identifier.parse(names[i]);
//                boolean enabled = fogEnabled || skyEnabled;
//                var parsedMod = Parsed.lowPriority(mod, id, enabled);
//                converted.put(id, parsedMod);
//            }
//        }
//        Polytone.DIMENSION_MODIFIERS.addConvertedBlockProperties(converted);
    }
}
