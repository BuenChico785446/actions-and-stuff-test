package net.mehvahdjukaar.polytone.content.noise;

import com.google.gson.JsonElement;
import com.mojang.serialization.Codec;
import net.mehvahdjukaar.codecui.SchemaCodec;
import net.mehvahdjukaar.codecui.SchemaRecord;
import net.mehvahdjukaar.polytone.common.struc.AssetsFiles;
import net.mehvahdjukaar.polytone.common.struc.MapRegistry;
import net.mehvahdjukaar.polytone.common.exp.ExpressionUtils;
import net.mehvahdjukaar.polytone.common.reloader.ContentManager;
import net.minecraft.core.HolderLookup;
import net.minecraft.resources.RegistryOps;
import net.minecraft.resources.Identifier;
import net.minecraft.util.RandomSource;
import org.jspecify.annotations.Nullable;

import java.util.List;
import java.util.Map;

public class NoiseManager extends ContentManager<OctaveSimplexNoise> {

    public static final SchemaCodec<OctaveSimplexNoise> NOISE_CODEC = SchemaRecord.create(OctaveSimplexNoise.class, i -> i.group(
            i.field("seed", Codec.INT, p -> 0),
            i.field("octaves", Codec.INT.listOf(), p -> List.of())
    ).apply(i, (s, l) -> new OctaveSimplexNoise(RandomSource.create(s), l)));

    public static final OctaveSimplexNoise DEFAULT =  new OctaveSimplexNoise(RandomSource.create(0), List.of(1));


    public NoiseManager() {
        super(Spec.of("Noise", () -> NOISE_CODEC)
                .wikiPage("Math-Expressions")
                .folders("noises"));
    }

    private final MapRegistry<OctaveSimplexNoise> noises = new MapRegistry<>("Polytone Simplex Noises");

    @Nullable
    public OctaveSimplexNoise getNoise(String id) {
        return noises.getValue(id);
    }

    @Override
    protected void resetWithLevel(boolean logOff) {
        noises.clear();
    }

    @Override
    protected void parseWithLevel(AssetsFiles resources, RegistryOps<JsonElement> ops,
                                  HolderLookup.Provider access) {
        Map<Identifier, JsonElement> jsons = resources.jsons();
        for (var e : jsons.entrySet()) {
            var id = e.getKey();
            var json = e.getValue();
            OctaveSimplexNoise noise = decodeStrict(json, id, ops);
            noises.register(id, noise);
        }
        ExpressionUtils.regenNoiseFunctions(noises.getEntries());
    }

    @Override
    protected void applyWithLevel(HolderLookup.Provider access, boolean isLogIn) {
    }
}
