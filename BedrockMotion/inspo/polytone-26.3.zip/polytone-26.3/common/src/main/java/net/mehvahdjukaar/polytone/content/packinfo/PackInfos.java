package net.mehvahdjukaar.polytone.content.packinfo;

import net.mehvahdjukaar.polytone.Polytone;
import net.minecraft.server.packs.PackMetadataResources;
import net.minecraft.server.packs.PackType;
import org.jspecify.annotations.Nullable;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class PackInfos {

    private static final Map<String, PackInfo> BY_PACK_ID = new ConcurrentHashMap<>();

    public static void readFrom(PackMetadataResources packResources, PackType packType) {
        if (packType != PackType.CLIENT_RESOURCES) return;
        String id = packResources.location().id();
        try {
            PackInfo info = packResources.getMetadataSection(PackInfo.TYPE);
            if (info != null && !info.isEmpty()) {
                BY_PACK_ID.put(id, info);
            } else {
                BY_PACK_ID.remove(id);
            }
        } catch (Exception e) {
            // never let this break pack discovery. vanilla would drop the whole pack
            BY_PACK_ID.remove(id);
            Polytone.LOGGER.warn("Failed to read Polytone info section of pack {}", id, e);
        }
    }

    public static @Nullable PackInfo get(String packId) {
        return BY_PACK_ID.get(packId);
    }
}
