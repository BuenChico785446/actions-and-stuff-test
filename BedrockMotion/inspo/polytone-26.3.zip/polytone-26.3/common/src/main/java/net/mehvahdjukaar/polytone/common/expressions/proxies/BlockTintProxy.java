package net.mehvahdjukaar.polytone.common.expressions.proxies;

import net.mehvahdjukaar.candlelight.api.BeanAliases;
import net.minecraft.client.renderer.block.BlockAndTintGetter;
import net.minecraft.util.ARGB;
import net.minecraft.world.level.biome.Biome;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;
import org.jspecify.annotations.Nullable;

@BeanAliases
public class BlockTintProxy extends BlockProxy {
    private final float r;
    private final float g;
    private final float b;

    public BlockTintProxy(@Nullable BlockAndTintGetter level, @Nullable Vec3 pos, @Nullable BlockState state,
                          @Nullable Biome biome, float r, float g, float b) {
        super(level, pos, state, biome);
        this.r = r;
        this.g = g;
        this.b = b;
    }

    public float red() {
        return r;
    }

    public float green() {
        return g;
    }

    public float blue() {
        return b;
    }

    public int color() {
        return ARGB.colorFromFloat(1, r, g, b);
    }
}
