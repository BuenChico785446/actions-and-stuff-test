package net.mehvahdjukaar.polytone.content.lightmap;

import com.mojang.serialization.Codec;
import net.mehvahdjukaar.codecui.SchemaCodecs;
import net.mehvahdjukaar.polytone.common.expressions.impl.LightmapExp;
import net.mehvahdjukaar.polytone.common.struc.MapRegistry;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;

public interface ILightmapNumberProvider {

    MapRegistry<ILightmapNumberProvider> BUILTIN_PROVIDERS = new MapRegistry<>("Lightmap Number Providers");

    // Same wire codec as always; the labels only name the editor's picker options.
    Codec<ILightmapNumberProvider> CODEC = Codec.lazyInitialized(() -> SchemaCodecs.labeled(
            SchemaCodecs.referenceOrDirect(BUILTIN_PROVIDERS,
                    SchemaCodecs.alternatives(LightmapContextExpression.CODEC, LightmapExp.TYPE.codec()), true),
            SchemaCodecs.alt("preset", BUILTIN_PROVIDERS),
            // expression before legacy: both encode as bare strings, so fit-scoring on load should
            // land on the modern branch, not the deprecated one.
            SchemaCodecs.alt("expression", LightmapExp.TYPE.codec()),
            SchemaCodecs.alt("legacy expression", LightmapContextExpression.CODEC)));


    double getValue(float time, float rain, float thunder);

    RandomSource RAND = RandomSource.create();

    // Sine
    ILightmapNumberProvider RANDOM = BUILTIN_PROVIDERS.register("random",
            (time, rain, thunder) -> {
                RAND.setSeed(Float.floatToIntBits(time));
                return RAND.nextFloat();
            });

    // Same stuff that level.getSkyDarkens does
    // A slanted Step
    ILightmapNumberProvider DEFAULT = BUILTIN_PROVIDERS.register("default",
            (time, rain, thunder) -> {
                double g = 1.0 - (Mth.cos(time * Mth.TWO_PI) * 2.0 + 0.2);
                g = Mth.clamp(g, 0.0, 1.0);
                g = 1.0 - g;
                // g *= 1.0F - rain * 5.0F / 16.0F;
                // g *= 1.0F - thunder * 5.0F / 16.0F;
                return g;
            });

    // Sine
    ILightmapNumberProvider SMOOTH = BUILTIN_PROVIDERS.register("smooth",
            (time, rain, thunder) -> 0.5 + (Mth.cos(time * Mth.TWO_PI) * 0.5));

    // Triangle func
    ILightmapNumberProvider LINEAR = BUILTIN_PROVIDERS.register("linear",
            (time, rain, thunder) -> Mth.abs(1 - 2 * time));

    ILightmapNumberProvider DEFAULT_2 = BUILTIN_PROVIDERS.register("default_2",
            (time, rain, thunder) -> {
                double g = 1.0 - (Mth.cos(time * Mth.TWO_PI) * 2.0 + 0.2);
                g = Mth.clamp(g, 0.0, 1.0);
                g = 1.0 - g;
                g *= 0.5;
                if (time > 0.5) {
                    return g;
                } else {
                    return 1 - g;
                }
            });

    // Sine Saw Tooth
    ILightmapNumberProvider SMOOTH_2 = BUILTIN_PROVIDERS.register("smooth_2",
            (time, rain, thunder) -> {
                if (time > 0.5) {
                    return 0.25 - (Mth.cos(time * Mth.TWO_PI) * 0.25);
                } else {
                    return 0.75 + (Mth.cos(time * Mth.TWO_PI) * 0.25);
                }
            });

    // Line (Saw Tooth)
    ILightmapNumberProvider LINEAR_2 = BUILTIN_PROVIDERS.register("linear_2",
            (time, rain, thunder) -> {
                float linear = Mth.abs(1 - 2 * time);
                if (time > 0.5) {
                    return linear * 0.5;
                } else {
                    return 1 - linear * 0.5;
                }
            });


}
