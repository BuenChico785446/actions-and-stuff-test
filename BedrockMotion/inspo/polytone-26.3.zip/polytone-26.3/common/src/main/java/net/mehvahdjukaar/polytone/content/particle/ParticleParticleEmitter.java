package net.mehvahdjukaar.polytone.content.particle;

import com.mojang.serialization.Codec;
import net.mehvahdjukaar.codecui.SchemaCodec;
import net.mehvahdjukaar.codecui.SchemaRecord;
import net.mehvahdjukaar.polytone.Polytone;
import net.mehvahdjukaar.polytone.common.TokenBucketTracker;
import net.mehvahdjukaar.codecui.SchemaCodecs;
import net.mehvahdjukaar.polytone.common.codec.CodecUtils;
import net.mehvahdjukaar.polytone.common.expressions.impl.IParticleExp;
import net.mehvahdjukaar.polytone.content.particle.custom.CustomParticleInstance;
import net.mehvahdjukaar.polytone.content.particle.custom.ExtraDataParticleOptions;
import net.mehvahdjukaar.polytone.content.particle.custom.IParticleTickable;
import net.mehvahdjukaar.polytone.content.particle.custom.PolytoneAsyncParticles;
import net.minecraft.client.particle.Particle;
import net.minecraft.util.RandomSource;
import net.minecraft.core.BlockPos;
import net.minecraft.core.HolderSet;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.registries.Registries;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.world.level.biome.Biome;
import net.minecraft.world.level.levelgen.structure.templatesystem.AlwaysTrueTest;
import net.minecraft.world.level.levelgen.structure.templatesystem.RuleTest;
import org.jetbrains.annotations.Nullable;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

public record ParticleParticleEmitter(
        ParticleSpec particle,
        IParticleExp chance,
        IParticleExp count,
        IParticleExp x,
        IParticleExp y,
        IParticleExp z,
        IParticleExp dx,
        IParticleExp dy,
        IParticleExp dz,
        Optional<IParticleExp> r,
        Optional<IParticleExp> g,
        Optional<IParticleExp> b,
        Optional<IParticleExp> a,
        Optional<IParticleExp> roll,
        Optional<IParticleExp> size,
        Optional<IParticleExp> custom,
        Map<String, IParticleExp> customs,
        RuleTest predicate,
        Optional<HolderSet<Biome>> biomes
) implements IParticleTickable {

    public static final SchemaCodec<ParticleParticleEmitter> CODEC = SchemaRecord.create(ParticleParticleEmitter.class, i -> i.group(
            i.field("particle", ParticleSpec.CODEC, ParticleParticleEmitter::particle),
            i.optional("chance", IParticleExp.CODEC_LEGACY, IParticleExp.ONE, ParticleParticleEmitter::chance),
            i.optional("count", IParticleExp.CODEC_LEGACY, IParticleExp.ONE, ParticleParticleEmitter::count),
            i.optional("x", IParticleExp.CODEC_LEGACY, IParticleExp.PARTICLE_RAND, ParticleParticleEmitter::x),
            i.optional("y", IParticleExp.CODEC_LEGACY, IParticleExp.PARTICLE_RAND, ParticleParticleEmitter::y),
            i.optional("z", IParticleExp.CODEC_LEGACY, IParticleExp.PARTICLE_RAND, ParticleParticleEmitter::z),
            i.optional("dx", IParticleExp.CODEC_LEGACY, IParticleExp.ZERO, ParticleParticleEmitter::dx),
            i.optional("dy", IParticleExp.CODEC_LEGACY, IParticleExp.ZERO, ParticleParticleEmitter::dy),
            i.optional("dz", IParticleExp.CODEC_LEGACY, IParticleExp.ZERO, ParticleParticleEmitter::dz),
            i.optional("red", IParticleExp.CODEC_LEGACY, ParticleParticleEmitter::r),
            i.optional("green", IParticleExp.CODEC_LEGACY, ParticleParticleEmitter::g),
            i.optional("blue", IParticleExp.CODEC_LEGACY, ParticleParticleEmitter::b),
            i.optional("alpha", IParticleExp.CODEC_LEGACY, ParticleParticleEmitter::a),
            i.optional("roll", IParticleExp.CODEC_LEGACY, ParticleParticleEmitter::roll),
            i.optional("size", IParticleExp.CODEC_LEGACY, ParticleParticleEmitter::size),
            i.optional("custom", IParticleExp.CODEC_LEGACY, ParticleParticleEmitter::custom),
            i.optional("customs", Codec.unboundedMap(Codec.STRING, IParticleExp.CODEC_LEGACY), Map.of(),
                    ParticleParticleEmitter::customs),
            i.field("state_predicate", SchemaCodecs.lenientWithLog(RuleTest.CODEC, "state_predicate", AlwaysTrueTest.INSTANCE), RuleTest.CODEC, ParticleParticleEmitter::predicate),
            i.optional("biomes", CodecUtils.forwardAwareHomogeneousList(Registries.BIOME), ParticleParticleEmitter::biomes)
    ).apply(i, ParticleParticleEmitter::new));


    @Override
    public void tick(Particle particle, ClientLevel level) {
        if (this.particle.isEmpty()) return;
        RandomSource rand = particle instanceof CustomParticleInstance cpi ? cpi.getRandom() : level.getRandom();
        float throttle = Polytone.CONFIGS.particlesThrottle.get();
        if (throttle < 1 && rand.nextFloat() > throttle) return;

        double spawnChance = chance.evaluate(particle, level);
        if (rand.nextFloat() < spawnChance) {
            if (biomes.isPresent() || predicate != AlwaysTrueTest.INSTANCE) {
                BlockPos pos = BlockPos.containing(particle.x, particle.y, particle.z);
                // off-thread (async particles): skip unloaded chunks, else the biome/air fallback misfires
                if (!level.hasChunkAt(pos)) return;
                if (biomes.isPresent() && !biomes.get().contains(level.getBiome(pos))) return;
                if (predicate != AlwaysTrueTest.INSTANCE && !predicate.test(level.getBlockState(pos), pos, rand)) return;
            }
            for (int i = 0; i < count.evaluate(particle, level); i++) {
                ParticleOptions po = getParticleOptions(particle, level);
                if (po == null) return;
                if (!TokenBucketTracker.canEmitParticle(this)) return;
                double sx = particle.x + x.evaluate(particle, level);
                double sy = particle.y + y.evaluate(particle, level);
                double sz = particle.z + z.evaluate(particle, level);
                double sdx = dx.evaluate(particle, level);
                double sdy = dy.evaluate(particle, level);
                double sdz = dz.evaluate(particle, level);
                ParticlePreviewState.EmitSink sink = ParticlePreviewState.sink();
                if (sink != null) {
                    sink.emit(level, po, sx, sy, sz, sdx, sdy, sdz);
                } else {
                    PolytoneAsyncParticles.deferToMain(() -> level.addParticle(po, sx, sy, sz, sdx, sdy, sdz));
                }
            }
        }
    }


    private @Nullable ParticleOptions getParticleOptions(Particle particle, ClientLevel level) {
        if (this.particle.isDynamic()) {
            Map<String, Float> map = new HashMap<>();
            r.ifPresent(exp -> map.put("red", (float) exp.evaluate(particle, level)));
            g.ifPresent(exp -> map.put("green", (float) exp.evaluate(particle, level)));
            b.ifPresent(exp -> map.put("blue", (float) exp.evaluate(particle, level)));
            a.ifPresent(exp -> map.put("alpha", (float) exp.evaluate(particle, level)));
            roll.ifPresent(exp -> map.put("roll", (float) exp.evaluate(particle, level)));
            size.ifPresent(exp -> map.put("size", (float) exp.evaluate(particle, level)));
            custom.ifPresent(exp -> map.put("custom", (float) exp.evaluate(particle, level)));
            customs.forEach((name, exp) -> map.put(ExtraDataParticleOptions.NAMED_CUSTOM_PREFIX + name,
                    (float) exp.evaluate(particle, level)));
            return new ExtraDataParticleOptions(map, this.particle.particleType());
        }

        return this.particle.resolveOptions(null);
    }

}
