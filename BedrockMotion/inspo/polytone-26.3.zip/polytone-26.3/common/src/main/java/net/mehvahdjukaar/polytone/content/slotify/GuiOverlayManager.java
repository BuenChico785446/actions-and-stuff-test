package net.mehvahdjukaar.polytone.content.slotify;

import com.google.gson.JsonElement;
import com.mojang.renderpearl.api.pipeline.RenderPipeline;
import net.mehvahdjukaar.polytone.common.reloader.ContentManager;
import net.mehvahdjukaar.polytone.common.struc.AssetsFiles;
import net.minecraft.client.gui.Hud;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.client.renderer.texture.TextureAtlasSprite;
import net.minecraft.core.HolderLookup;
import net.minecraft.resources.RegistryOps;
import net.minecraft.resources.Identifier;
import net.minecraft.server.packs.resources.PreparableReloadListener;
import net.minecraft.server.packs.resources.ResourceManager;

import java.util.*;

public class GuiOverlayManager extends ContentManager<BlitModifier> {

    private final Map<Hud.HeartType, HeartSprites> heartSprites = new EnumMap<>(Hud.HeartType.class);
    private final List<BlitModifier> blitModifiers = new ArrayList<>();
    private final Map<Identifier, BlitModifier> blitModifiersCache = new HashMap<>();

    public GuiOverlayManager() {
        super(Spec.of("Overlay modifier", () -> BlitModifier.CODEC)
                .wikiPage("Screen-Sprite-Modifiers")
                .folders("overlay_modifiers"));
    }

    @Override
    protected void resetWithLevel(boolean logOff) {
        blitModifiers .clear();
        blitModifiersCache.clear();
    }

    @Override
    protected void parseWithLevel(AssetsFiles resources, RegistryOps<JsonElement> ops,
                                  HolderLookup.Provider access) {
        for (var j : parseEnabledJsons(resources.jsons(), ops)) {
            blitModifiers.add(j.getValue());
        }
    }

    @Override
    protected void applyWithLevel(HolderLookup.Provider access, boolean isLogIn) {

    }

    @Override
    protected AssetsFiles prepare(PreparableReloadListener.SharedState sharedState) {
        var resourceManager = sharedState.resourceManager();
        reloadHearths(resourceManager);
        return super.prepare(sharedState);
    }

    private int index = 0;
    private boolean active = false;

    public boolean maybeModifyBlit(GuiGraphicsExtractor gui, RenderPipeline pipeline, TextureAtlasSprite sprite,
                                   int x, int y, int width, int height, int color) {
        if (!active || blitModifiers.isEmpty()) return false;
        var mod = getMod(sprite);
        if (mod != null) {
            int ind = mod.index();
            boolean matches = ind == -1 || ind == index;
            index++;
            if (matches) {
                mod.blitModified(gui, pipeline, sprite,
                        x, x + width, y, y + height,
                        sprite.getU0(), sprite.getU1(), sprite.getV0(), sprite.getV1(),
                        color);
                return true;
            }
        }
        return false;
    }

    private BlitModifier getMod(TextureAtlasSprite sprite) {
        Identifier id = sprite.contents().name();
        if (blitModifiersCache.containsKey(id)) return blitModifiersCache.get(id);
        BlitModifier found = null;
        for (var m : blitModifiers) {
            if (m.target().test(id)) {
                found = m;
                break;
            }
        }
        blitModifiersCache.put(id, found);
        return found;
    }

    //partial blit
    public boolean maybeModifyBlit(GuiGraphicsExtractor gui, RenderPipeline pipeline, TextureAtlasSprite sprite,
                                   int x, int y,
                                   int textureWidth, int textureHeight,
                                   int uPosition, int vPosition, int uWidth, int vHeight,
                                   int color) {
        if (!active || blitModifiers.isEmpty()) return false;
        var mod = getMod(sprite);
        if (mod != null) {
            int ind = mod.index();
            boolean matches = ind == -1 || ind == index;
            index++;
            if (matches) {
                mod.blitModified(gui, pipeline, sprite,
                        x, x + uWidth, y, y + vHeight,
                        sprite.getU((float) uPosition / (float) textureWidth),
                        sprite.getU((float) (uPosition + uWidth) / (float) textureWidth),
                        sprite.getV((float) vPosition / (float) textureHeight),
                        sprite.getV((float) (vPosition + vHeight) / (float) textureHeight),
                        color);
                return true;
            }
        }
        return false;
    }

    public void onStartRenderingOverlay() {
        index = 0;
        active = true;
    }

    public void onEndRenderingOverlay() {
        active = false;
    }


    private void reloadHearths(ResourceManager manager) {
        heartSprites.clear();
        for (var h : Hud.HeartType.values()) {
            if (h != Hud.HeartType.CONTAINER && h != Hud.HeartType.NORMAL) {
                String name = h.name().toLowerCase(Locale.ROOT);
                Identifier fullRes = Identifier.parse("textures/gui/sprites/polytone/heart/container_" + name + "_full.png");
                Identifier halfRes = Identifier.parse("textures/gui/sprites/polytone/heart/container_" + name + "_half.png");
                if (manager.getResource(fullRes).isPresent() && manager.getResource(halfRes).isPresent()) {
                    Identifier fullBlinkingRes = Identifier.parse("textures/gui/sprites/polytone/heart/container_" + name + "_full_blinking.png");
                    var fullBlinking = manager.getResource(fullBlinkingRes);
                    Identifier halfBlinkingRes = Identifier.parse("textures/gui/sprites/polytone/heart/container_" + name + "_half_blinking.png");
                    var halfBlinking = manager.getResource(halfBlinkingRes);
                    Identifier hardcoreFullRes = Identifier.parse("textures/gui/sprites/polytone/heart/container_" + name + "_hardcore_full.png");
                    var hardcoreFull = manager.getResource(hardcoreFullRes);
                    Identifier hardcoreFullBlinkingRes = Identifier.parse("textures/gui/sprites/polytone/heart/container_" + name + "_hardcore_full_blinking.png");
                    var hardcoreFullBlinking = manager.getResource(hardcoreFullBlinkingRes);
                    Identifier hardcoreHalfRes = Identifier.parse("textures/gui/sprites/polytone/heart/container_" + name + "_hardcore_half.png");
                    var hardcoreHalf = manager.getResource(hardcoreHalfRes);
                    Identifier hardcoreHalfBlinkingRes = Identifier.parse("textures/gui/sprites/polytone/heart/container_" + name + "_hardcore_half_blinking.png");
                    var hardcoreHalfBlinking = manager.getResource(hardcoreHalfBlinkingRes);

                    if (fullBlinking.isEmpty()) {
                        fullBlinkingRes = fullRes;
                    }
                    if (halfBlinking.isEmpty()) {
                        halfBlinkingRes = halfRes;
                    }
                    if (hardcoreFull.isEmpty()) {
                        hardcoreFullRes = fullRes;
                    }
                    if (hardcoreFullBlinking.isEmpty()) {
                        hardcoreFullBlinkingRes = hardcoreFullRes;
                    }
                    if (hardcoreHalf.isEmpty()) {
                        hardcoreHalfRes = halfRes;
                    }
                    if (hardcoreHalfBlinking.isEmpty()) {
                        hardcoreHalfBlinkingRes = hardcoreHalfRes;
                    }
                    fullRes = fullRes.withPath(p -> p.replace("textures/gui/sprites/", "").replace(".png", ""));
                    halfRes = halfRes.withPath(p -> p.replace("textures/gui/sprites/", "").replace(".png", ""));
                    fullBlinkingRes = fullBlinkingRes.withPath(p -> p.replace("textures/gui/sprites/", "").replace(".png", ""));
                    halfBlinkingRes = halfBlinkingRes.withPath(p -> p.replace("textures/gui/sprites/", "").replace(".png", ""));
                    hardcoreFullRes = hardcoreFullRes.withPath(p -> p.replace("textures/gui/sprites/", "").replace(".png", ""));
                    hardcoreFullBlinkingRes = hardcoreFullBlinkingRes.withPath(p -> p.replace("textures/gui/sprites/", "").replace(".png", ""));
                    hardcoreHalfRes = hardcoreHalfRes.withPath(p -> p.replace("textures/gui/sprites/", "").replace(".png", ""));
                    hardcoreHalfBlinkingRes = hardcoreHalfBlinkingRes.withPath(p -> p.replace("textures/gui/sprites/", "").replace(".png", ""));
                    heartSprites.put(h, new HeartSprites(fullRes, halfRes, fullBlinkingRes, halfBlinkingRes,
                            hardcoreFullRes, hardcoreHalfRes, hardcoreFullBlinkingRes, hardcoreHalfBlinkingRes));
                }
            }
        }
    }

    public boolean maybeFancifyHeart(Hud instance, GuiGraphicsExtractor graphics, Hud.HeartType actualType, int i, int j, boolean bl, boolean bl2, boolean bl3) {
        if (heartSprites.isEmpty()) return false;
        HeartSprites sprites = heartSprites.get(actualType);
        if (sprites != null) {
            graphics.blitSprite(RenderPipelines.GUI_TEXTURED, sprites.getSprite(bl, bl3, bl2), i, j, 9, 9);
            return true;
        }
        return false;
    }


    private record HeartSprites(Identifier full, Identifier half, Identifier fullBlinking,
                                Identifier halfBlinking, Identifier hardcoreFull,
                                Identifier hardcoreHalf, Identifier hardcoreFullBlinking,
                                Identifier hardcoreHalfBlinking) {

        public Identifier getSprite(boolean bl, boolean bl2, boolean bl3) {
            if (!bl) {
                if (bl2) {
                    return bl3 ? this.halfBlinking : this.half;
                } else {
                    return bl3 ? this.fullBlinking : this.full;
                }
            } else if (bl2) {
                return bl3 ? this.hardcoreHalfBlinking : this.hardcoreHalf;
            } else {
                return bl3 ? this.hardcoreFullBlinking : this.hardcoreFull;
            }
        }

    }

}
