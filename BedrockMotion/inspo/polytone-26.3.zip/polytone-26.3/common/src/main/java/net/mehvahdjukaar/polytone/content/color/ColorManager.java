package net.mehvahdjukaar.polytone.content.color;

import com.google.common.collect.Lists;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;
import com.google.gson.JsonPrimitive;
import com.mojang.serialization.Codec;
import com.mojang.serialization.JsonOps;
import it.unimi.dsi.fastutil.objects.Object2IntMap;
import it.unimi.dsi.fastutil.objects.Object2IntOpenHashMap;
import net.mehvahdjukaar.polytone.Polytone;
import net.mehvahdjukaar.polytone.common.ColorUtils;
import net.mehvahdjukaar.polytone.common.expressions.impl.IEntityExp;
import net.mehvahdjukaar.polytone.common.struc.AssetsFiles;
import net.mehvahdjukaar.polytone.common.reloader.SingleFileContentManager;
import net.mehvahdjukaar.polytone.common.struc.Vec3f;
import net.mehvahdjukaar.polytone.content.colormap.BiomeColorResolvers;
import net.mehvahdjukaar.polytone.content.colormap.Colormap;
import net.mehvahdjukaar.polytone.content.colormap.IColorGetter;
import net.mehvahdjukaar.polytone.content.entity.IRenderStateWithId;
import net.mehvahdjukaar.polytone.mixins.accessor.DustParticleOptionAccessor;
import net.minecraft.client.Minecraft;
import net.minecraft.client.color.ColorLerper;
import net.minecraft.client.renderer.entity.state.ExperienceOrbRenderState;
import net.minecraft.client.resources.SplashManager;
import net.minecraft.core.HolderLookup;
import net.minecraft.core.particles.ColorParticleOption;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.Style;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.RegistryOps;
import net.minecraft.util.ARGB;
import net.minecraft.util.GsonHelper;
import net.minecraft.util.Mth;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.item.DyeColor;
import net.minecraft.world.item.alchemy.PotionContents;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.RedstoneWireBlock;
import net.minecraft.world.level.border.BorderStatus;
import net.minecraft.world.level.material.MapColor;
import org.jetbrains.annotations.Nullable;

import java.util.*;
import java.util.function.BiConsumer;
import java.util.function.Function;

import static net.minecraft.world.effect.MobEffect.AMBIENT_ALPHA;

public class ColorManager extends SingleFileContentManager<Void> {

    private static final int DEFAULT_COLOR = ARGB.colorFromFloat(1.0f, 1, 0, 0);
    private final Object2IntMap<MapColor> vanillaMapColors = new Object2IntOpenHashMap<>();
    private final Map<DyeColor, Integer> vanillaFireworkColors = new EnumMap<>(DyeColor.class);
    private final Map<DyeColor, Integer> vanillaDiffuseColors = new EnumMap<>(DyeColor.class);
    private final Map<DyeColor, Integer> vanillaTextColors = new EnumMap<>(DyeColor.class);
    private final Object2IntMap<MobEffect> vanillaEffectColors = new Object2IntOpenHashMap<>();
    private final Map<MobEffect, Function<MobEffectInstance, ParticleOptions>> vanillaEffectParticles = new HashMap<>();
    private final EnumMap<BorderStatus, Integer> vanillaBorderStatus = new EnumMap<>(BorderStatus.class);

    private final Map<DyeColor, Integer> customSheepColors = new EnumMap<>(DyeColor.class);
    private final Map<DyeColor, Integer> originalSheepColors = new EnumMap<>(ColorLerper.Type.SHEEP.colorByDye);

    protected final int[] originalRedstoneWireColors = Arrays.copyOf(RedstoneWireBlock.COLORS, RedstoneWireBlock.COLORS.length);

    protected final Style originalSplash = SplashManager.DEFAULT_STYLE;

    @Nullable
    Identifier xpOrbParticle;
    @Nullable
    private IEntityExp xpOrbColor;
    @Nullable
    private IEntityExp xpOrbColorR;
    @Nullable
    private IEntityExp xpOrbColorG;
    @Nullable
    private IEntityExp xpOrbColorB;

    private Integer xpBar = null;
    private Integer xpBarBack = null;
    private Integer enchantTableXp = null;

    private Integer skyFlashColor = null;
    @Nullable
    private Integer powderSnowFogColor = null;
    @Nullable
    private Float blindnessFogDistance = null;
    @Nullable
    private Float darknessFogDistance = null;
    @Nullable
    private Float bossFogDistance = null;
    private Integer voidDarknessOffset = null;
    private Integer horizonHeight = null;

    private float waterFogBrightening = 1;
    private int waterFogBrighteningTime = 600;

    @Nullable
    private Integer fishingLineColor = null;
    @Nullable
    private Vec3f fishingLineOffset = null;

    @Nullable
    private PaintingRenderType paintingRenderType = null;

    private boolean entityShadowsDisabled = false;

    //don't use pls
    @Nullable
    private Integer swampDark = null;
    @Nullable
    private Integer swampLight = null;
    @Nullable
    private Integer darkForest = null;

    public ColorManager() {
        //determines the priority. last applied will be the one with highest priority. Polytone is last applied one
        super("Color Manager",
                "color.properties", "colors.json",
                Polytone.MOD_ID, "colormatic", "vanadium", "optifine");
    }

    public Integer getSkyFlash() {
        return skyFlashColor;
    }

    public Integer getVoidDarknessOffset() {
        return voidDarknessOffset;
    }

    public Integer getHorizonHeight() {
        return horizonHeight;
    }

    @Nullable
    public Integer getPowderSnowFogColor() {
        return powderSnowFogColor;
    }

    public float getBlindnessFogDistance(float vanilla) {
        return blindnessFogDistance != null ? blindnessFogDistance : vanilla;
    }

    public float getDarknessFogDistance(float vanilla) {
        return darknessFogDistance != null ? darknessFogDistance : vanilla;
    }

    public float getBossFogDistance(float vanilla) {
        return bossFogDistance != null ? bossFogDistance : vanilla;
    }

    public float getWaterFogBrightening() {
        return waterFogBrightening;
    }

    public float getWaterVisionTimeScale() {
        return waterFogBrighteningTime / 600f;
    }

    public Integer getXpBar() {
        return xpBar;
    }

    public Integer getXpBarBackground() {
        return xpBarBack;
    }

    public @Nullable Integer getSpecialSwampDark() {
        return swampDark;
    }

    public @Nullable Integer getSpecialSwampLight() {
        return swampLight;
    }

    public @Nullable Integer getSpecialDarkForest() {
        return darkForest;
    }

    @Override
    protected void parseWithLevel(AssetsFiles resources, RegistryOps<JsonElement> ops, HolderLookup.Provider access) {
        Map<Identifier, JsonElement> jsons = resources.jsons();
        var keySet = new ArrayList<>(jsons.keySet());

        for (var k : Lists.reverse(keySet)) {
            JsonElement root = jsons.get(k);
            try {
                parseColorJson(root, k, ops);
            } catch (Exception e1) {
                Polytone.LOGGER.error("Failed to parse color.json in file {}", k, e1);
            }
        }

        regenSheepColors();
    }

    private void parseColorJson(JsonElement root, Identifier fileId, RegistryOps<JsonElement> ops) {
        JsonObject obj = root.getAsJsonObject();

        doWith(obj, "map", (k, v) -> {
            MapColor color = MapColorHelper.byName(k);
            if (color != null) {
                int col = parseColor(v);
                if (!vanillaMapColors.containsKey(color)) {
                    vanillaMapColors.put(color, color.col);
                }
                color.col = col;
            } else Polytone.LOGGER.warn("Unknown MapColor with name {}", k);
        });

        doWith(obj, "environment", (k, e) -> {
            switch (k) {
                case "sky_flash":
                    skyFlashColor = parseColor(e);
                    return;
                case "void_darkness_offset":
                    voidDarknessOffset = parseInt(e);
                    return;
                case "horizon_height":
                    horizonHeight = parseInt(e);
                    return;
                case "water_fog_brightening":
                    waterFogBrightening = Mth.clamp(parseFloat(e), 0, 1);
                    return;
                case "water_fog_brightening_time":
                    waterFogBrighteningTime = Math.max(1, parseInt(e));
                    return;
                case "powder_snow_fog":
                    powderSnowFogColor = parseColor(e);
                    return;
                case "blindness_fog_distance":
                    blindnessFogDistance = parseFloat(e);
                    return;
                case "darkness_fog_distance":
                    darknessFogDistance = parseFloat(e);
                    return;
                case "boss_fog_distance":
                    bossFogDistance = parseFloat(e);
            }
        });

        doWith(obj, "dye", (k, v) -> {
            DyeColor color = DyeColor.byName(k, null);
            if (color == null) {
                Polytone.LOGGER.warn("Unknown DyeColor with name {}", k);
                return;
            }
            for (var entry : entries(v)) {
                String param = entry.getKey();
                int col = parseColor(entry.getValue());
                switch (param) {
                    case "diffuse" -> {
                        if (!vanillaDiffuseColors.containsKey(color)) {
                            vanillaDiffuseColors.put(color, color.getTextureDiffuseColor());
                        }
                        color.textureDiffuseColor = ARGB.opaque(col);
                    }
                    case "firework" -> {
                        if (!vanillaFireworkColors.containsKey(color)) {
                            vanillaFireworkColors.put(color, color.fireworkColor);
                        }
                        color.fireworkColor = col;
                    }
                    case "text" -> {
                        if (!vanillaTextColors.containsKey(color)) {
                            vanillaTextColors.put(color, color.textColor);
                        }
                        color.textColor = col;
                    }
                }
            }
        });

        doWith(obj, "special_grass_color", (k, v) -> {
            int hex = parseColor(v);
            switch (k) {
                case "swamp_dark" -> {
                    swampDark = hex;
                }
                case "swamp_light" -> {
                    swampLight = hex;
                }
                case "dark_forest" -> {
                    darkForest = hex;
                }
            }
        });

        doWith(obj, "biome_colors", (k, v) -> {
            BiomeColorResolvers target = BiomeColorResolvers.byKey(k);
            if (target == null) {
                Polytone.LOGGER.warn("Unknown biome color {}. Must be one of: grass, foliage, dry_foliage, water", k);
                return;
            }
            IColorGetter colormap = Colormap.CODEC.decode(ops, v).getOrThrow().getFirst();
            if (!target.replaceExplicitly(Polytone.COLORMAPS.getOrCreateConcurrentColormap(colormap))) {
                Polytone.LOGGER.warn("Biome color {} can't use an expression color, got {}", k, v);
            }
        });

        doWith(obj, "particle", (k, v) -> {
            Identifier id = Identifier.parse(k.replace("\\", ""));
            try {
                // turn from hex to decimal if it is a single number
                int hex = parseColor(v);
                Polytone.PARTICLE_MODIFIERS.addCustomParticleColor(id, String.valueOf(hex));
            } catch (Exception e) {
                Polytone.PARTICLE_MODIFIERS.addCustomParticleColor(id, v.getAsString());
            }

        });

        doWith(obj, "fishing_line", (k, v) -> {
            switch (k) {
                case "color" -> {
                    fishingLineColor = parseColor(v);
                }
                case "offset" -> {
                    fishingLineOffset = Vec3f.CODEC.decode(JsonOps.INSTANCE, v)
                            .getOrThrow()
                            .getFirst();
                }
            }

        });

        doWith(obj, "world_border", (k, v) -> {
            BorderStatus status = BorderStatus.valueOf(k.toLowerCase(Locale.ROOT));
            int col = parseColor(v);
            if (!vanillaBorderStatus.containsKey(status)) {
                vanillaBorderStatus.put(status, status.getColor());
            }
            status.color = col;
        });

        //for jank of compat... no comment
        doWithOrAlias(obj, List.of("effect", "potion"), (k, v) -> {
            Identifier id = Identifier.parse(k.replace("\\", ""));
            ParticleOptions particle = get(v, "particle", ParticleTypes.CODEC);

            String color = getString(v, "color");
            int col;

            if (color == null && v instanceof JsonPrimitive) {
                col = parseColor(v);
            } else {
                col = parseColor(color);
            }


            if (id.getPath().equals("empty")) {
                // TODO: handle PotionContents.EMPTY_COLOR
            } else if (id.getPath().equals("water")) {
                PotionContents.BASE_POTION_COLOR = col;
            } else {
                MobEffect effect = BuiltInRegistries.MOB_EFFECT.getOptional(id).orElse(null);
                if (effect != null) {
                    if (!vanillaEffectColors.containsKey(effect)) {
                        vanillaEffectColors.put(effect, effect.getColor());
                    }

                    effect.color = col;
                    effect.particleFactory = mobEffectInstance -> {
                        int alpha = mobEffectInstance.isAmbient() ? AMBIENT_ALPHA : 255;
                        return ColorParticleOption.create(ParticleTypes.ENTITY_EFFECT, ARGB.color(alpha, col));
                    };
                    if (particle != null) {
                        if (!vanillaEffectParticles.containsKey(effect)) {
                            vanillaEffectParticles.put(effect, effect.particleFactory);
                        }
                        effect.particleFactory = mobEffectInstance -> particle;
                    }
                } else Polytone.LOGGER.warn("Unknown Mob Effect with name {}", id);
            }
        });

        doWith(obj, "sheep", (k, v) -> {
            DyeColor color = DyeColor.byName(k, null);
            if (color != null) {
                int col = ARGB.opaque(parseColor(v));
                customSheepColors.put(color, col);
            } else Polytone.LOGGER.warn("Unknown Dye Color with name {}", k);
        });

        doWith(obj, "xporb", (k, v) -> {
            switch (k) {
                case "particle_replacement" -> Polytone.PARTICLE_MODIFIERS.setXpOrbReplace(v);
                case "color" -> xpOrbColor = parseEntityExp(v);
                case "red" -> xpOrbColorR = parseEntityExp(v);
                case "green" -> xpOrbColorG = parseEntityExp(v);
                case "blue" -> xpOrbColorB = parseEntityExp(v);
            }
        });

        doWith(obj, "redstone", (k, v) -> {
            int code = Integer.parseInt(k);
            if (code < RedstoneWireBlock.COLORS.length) {
                int col = parseColor(v);
                var rgb = ColorUtils.unpack(col);
                RedstoneWireBlock.COLORS[code] = ARGB.colorFromFloat(1.0f, rgb[0], rgb[1], rgb[2]);
                if (code == 15) {
                    int maxPower = ARGB.colorFromFloat(1.0f, rgb[0], rgb[1], rgb[2]);
                    net.minecraft.core.particles.DustParticleOptions.REDSTONE_PARTICLE_COLOR = maxPower;
                    ((DustParticleOptionAccessor) DustParticleOptions.REDSTONE).setColor(maxPower);
                }
            } else Polytone.LOGGER.warn("Redstone color index must be between 0 and 15");
        });

        doWith(obj, "text", (k, v) -> {
            //TODO: this wont be applied unless we are into a level...
            if (k.equals("splash")) {
                int splashCol = parseColor(v);
                refreshSplash(Style.EMPTY.withColor(splashCol));
            } else if (k.equals("xpbar")) {
                if (v instanceof JsonPrimitive) {
                    xpBar = parseColor(v);
                } else {
                    for (var e : entries(v)) {
                        switch (e.getKey()) {
                            case "foreground" -> xpBar = parseColor(e.getValue());
                            case "background" -> xpBarBack = parseColor(e.getValue());
                        }
                    }
                }
            } else if (k.startsWith("code:") || k.equals("code")) {
                // 26.2: legacy §-code recoloring removed. ChatFormatting/TextColor are now immutable
                // (no getById/getByName/color field), so globally overriding the 16 vanilla chat
                // color codes is no longer supported.
                Polytone.LOGGER.warn("Recoloring legacy chat formatting codes ('{}') is no longer supported as of MC 26.2", k);
            } else {
                Polytone.LOGGER.warn("Unsupported 'text' color key '{}'. Recoloring named chat formatting is no longer supported as of MC 26.2", k);
            }
        });

        doWith(obj, "palette", (k, v) -> {
            if (k.equals("block") && v.isJsonObject()) {
                for (var entry : getEntries(v.getAsJsonObject(), "block")) {
                    String path = entry.getKey().replace("~/colormap/", fileId.getNamespace() + ":");
                    Polytone.BLOCK_MODIFIERS.addSimpleColormap(Identifier.parse(path), entry.getValue().getAsString());
                }
            }
        });

        doWith(obj, "render_type", (k, v) -> {
            if (k.equals("painting")) {
                PaintingRenderType type = PaintingRenderType.byName(v.getAsString());
                if (type != null) {
                    paintingRenderType = type;
                } else Polytone.LOGGER.warn("Unknown painting render type {}. Must be one of: solid, cutout, translucent", v.getAsString());
            }
        });

        if (obj.has("entity_shadows")) {
            JsonElement v = obj.get("entity_shadows");
            if (v.isJsonPrimitive()) {
                // false disables the blob shadows rendered under entities. getAsBoolean also accepts the string "false" from .properties files
                entityShadowsDisabled = !v.getAsBoolean();
            }
        }
    }

    private void refreshSplash(Style style) {
        SplashManager.DEFAULT_STYLE = style;
        SplashManager manager = Minecraft.getInstance().gui.splashManager();
        var splashes = manager.splashes;
        List<Component> newSplashes = new ArrayList<>();
        for (Component c : splashes) {
            newSplashes.add(c.copy().withStyle(style));
        }
        manager.splashes = newSplashes;
    }


    private static void doWith(JsonElement o, String key, BiConsumer<String, JsonElement> entryHandler) {
        if (!(o instanceof JsonObject obj)) return;
        try {
            if (obj.has(key)) {
                JsonObject sub = GsonHelper.getAsJsonObject(obj, key);
                for (var entry : sub.entrySet()) {
                    entryHandler.accept(entry.getKey(), entry.getValue());
                }
            }
        } catch (JsonParseException e) {
            throw new JsonParseException("Failed to parse color JSON for key: " + key, e);
        }
    }

    private static void doWithOrAlias(JsonObject obj, Collection<String> names, BiConsumer<String, JsonElement> entryHandler) {
        for (var s : names) {
            doWith(obj, s, entryHandler);
        }
    }

    private static Set<Map.Entry<String, JsonElement>> getEntries(JsonObject element, String key) {
        var elements = element.get(key);
        if (elements != null && elements.isJsonObject()) {
            return elements.getAsJsonObject().entrySet();
        }
        return Collections.emptySet();
    }

    @Nullable
    private static <T> T get(JsonElement element, String key, Codec<T> codec) {
        if (element instanceof JsonObject jo) {
            JsonElement joo = jo.get(key);
            if (joo != null) {
                return codec.decode(JsonOps.INSTANCE, joo).getOrThrow().getFirst();
            }
        }
        return null;
    }

    private static String getString(JsonElement element, String key) {
        if (element instanceof JsonObject jo) {
            JsonElement joo = jo.get(key);
            if (joo != null && joo.isJsonPrimitive() && joo.getAsJsonPrimitive().isString()) {
                return joo.getAsString();
            }
        }
        return null;
    }

    private static Set<Map.Entry<String, JsonElement>> entries(JsonElement element) {
        if (element.isJsonObject()) {
            return element.getAsJsonObject().entrySet();
        }
        return Collections.emptySet();
    }

    private static int parseInt(JsonElement element) {
        //get as int or parse string as int
        if (element instanceof JsonPrimitive jp) {

            if (jp.isString()) {
                return Integer.parseInt(jp.getAsString());
            }
            if (jp.isNumber()) {
                return jp.getAsInt();
            }
        }
        throw new IllegalStateException("Failed to parse numerical element. Must be an integer! " + element);
    }

    private static float parseFloat(JsonElement element) {
        if (element instanceof JsonPrimitive jp) {
            if (jp.isString()) {
                return Float.parseFloat(jp.getAsString());
            }
            if (jp.isNumber()) {
                return jp.getAsFloat();
            }
            if (jp.isBoolean()) {
                return jp.getAsBoolean() ? 1 : 0;
            }
        }
        throw new IllegalStateException("Failed to parse numerical element. Must be a number! " + element);
    }

    private static int parseColor(JsonElement obj) {
        return ColorUtils.COLOR.decode(JsonOps.INSTANCE, obj)
                .getOrThrow()
                .getFirst(); // this will throw if the element is not a valid color
    }

    private static IEntityExp parseEntityExp(JsonElement obj) {
        return IEntityExp.CODEC.decode(JsonOps.INSTANCE, obj)
                .getOrThrow()
                .getFirst();
    }

    private static int parseColor(String str) {
        str = str.replace("#", "").replace("0x", "");
        return Integer.parseInt(str.trim(), 16);
    }

    @Override
    protected void applyWithLevel(HolderLookup.Provider access, boolean isLogIn) {

    }

    @Override
    protected void resetWithLevel(boolean logOff) {
        //TODO: potion empty
        //PotionContents.EMPTY_COLOR = 16253176;
        PotionContents.BASE_POTION_COLOR = 3694022;
        xpBar = null;
        xpOrbParticle = null;
        xpOrbColor = null;
        xpOrbColorR = null;
        xpOrbColorG = null;
        xpOrbColorB = null;
        fishingLineOffset = null;
        fishingLineColor = null;
        paintingRenderType = null;
        entityShadowsDisabled = false;
        skyFlashColor = null;
        voidDarknessOffset = null;
        horizonHeight = null;
        waterFogBrightening = 1;
        waterFogBrighteningTime = 600;
        powderSnowFogColor = null;
        blindnessFogDistance = null;
        darknessFogDistance = null;
        bossFogDistance = null;
        BiomeColorResolvers.resetAll();
        // map colors
        for (var e : vanillaMapColors.entrySet()) {
            MapColor color = e.getKey();
            color.col = e.getValue();
        }
        vanillaMapColors.clear();

        // dye colors
        for (var e : vanillaDiffuseColors.entrySet()) {
            DyeColor color = e.getKey();
            color.textureDiffuseColor = e.getValue();
        }
        vanillaDiffuseColors.clear();

        for (var e : vanillaFireworkColors.entrySet()) {
            DyeColor color = e.getKey();
            color.fireworkColor = e.getValue();
        }
        vanillaFireworkColors.clear();

        for (var e : vanillaTextColors.entrySet()) {
            DyeColor color = e.getKey();
            color.textColor = e.getValue();
        }
        vanillaTextColors.clear();

        //effects
        for (var e : vanillaEffectColors.object2IntEntrySet()) {
            MobEffect effect = e.getKey();
            effect.color = e.getIntValue();
        }
        vanillaEffectColors.clear();

        for (var e : vanillaEffectParticles.entrySet()) {
            MobEffect effect = e.getKey();
            effect.particleFactory = e.getValue();
        }
        vanillaEffectParticles.clear();

        //border status
        for (var e : vanillaBorderStatus.entrySet()) {
            BorderStatus status = e.getKey();
            status.color = e.getValue();
        }
        vanillaBorderStatus.clear();

        RedstoneWireBlock.COLORS = Arrays.copyOf(originalRedstoneWireColors, originalRedstoneWireColors.length);
        DustParticleOptions.REDSTONE_PARTICLE_COLOR = DEFAULT_COLOR;//default
        ((DustParticleOptionAccessor) DustParticleOptions.REDSTONE).setColor(DustParticleOptions.REDSTONE_PARTICLE_COLOR);
    }

    public void regenSheepColors() {
        var map = new EnumMap<>(originalSheepColors);
        map.putAll(customSheepColors);
        customSheepColors.clear();

        ColorLerper.Type.SHEEP.colorByDye = map;
    }

    public float @Nullable [] getXpOrbColor(ExperienceOrbRenderState orb, float partialTicks) {
        if (xpOrbColor == null && xpOrbColorR == null && xpOrbColorG == null && xpOrbColorB == null) return null;
        Level level = Minecraft.getInstance().level;
        if (level == null) return null;
        int id = ((IRenderStateWithId) orb).polytone$getId();
        Entity entity = level.getEntity(id);
        if (entity == null) return null;
        if (xpOrbColor != null) {
            int color = (int) xpOrbColor.evaluate(entity);
            return ColorUtils.unpack(color);
        }
        float r = 0;
        float g = 0;
        float b = 0;
        if (xpOrbColorR != null) r = (float) xpOrbColorR.evaluate(entity);
        if (xpOrbColorG != null) g = (float) xpOrbColorG.evaluate(entity);
        if (xpOrbColorB != null) b = (float) xpOrbColorB.evaluate(entity);
        return new float[]{r, g, b};
    }


    @Nullable
    public Vec3f getFishingLineOffset() {
        return fishingLineOffset;
    }

    @Nullable
    public Integer getFishingLineColor() {
        return fishingLineColor;
    }

    @Nullable
    public PaintingRenderType getPaintingRenderType() {
        return paintingRenderType;
    }

    public boolean areEntityShadowsDisabled() {
        return entityShadowsDisabled;
    }
}
