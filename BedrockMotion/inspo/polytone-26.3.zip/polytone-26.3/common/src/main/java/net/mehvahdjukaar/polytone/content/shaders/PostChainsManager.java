package net.mehvahdjukaar.polytone.content.shaders;

import com.google.gson.JsonElement;
import com.mojang.renderpearl.api.GpuFormat;
import com.mojang.renderpearl.api.buffers.GpuBuffer;
import com.mojang.renderpearl.api.buffers.GpuBufferSlice;
import com.mojang.blaze3d.framegraph.FrameGraphBuilder;
import com.mojang.renderpearl.api.pipeline.RenderPipeline;
import com.mojang.blaze3d.pipeline.RenderTarget;
import com.mojang.blaze3d.pipeline.TextureTarget;
import com.mojang.blaze3d.resource.GraphicsResourceAllocator;
import com.mojang.renderpearl.api.commands.RenderPass;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.renderpearl.api.textures.FilterMode;
import com.mojang.renderpearl.api.textures.GpuSampler;
import com.mojang.renderpearl.api.textures.GpuTextureView;
import net.mehvahdjukaar.polytone.Polytone;
import net.mehvahdjukaar.polytone.PolytoneRenderTypes;
import net.mehvahdjukaar.polytone.common.ClientFrameTicker;
import net.mehvahdjukaar.polytone.common.reloader.ContentManager;
import net.mehvahdjukaar.polytone.common.struc.AssetsFiles;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.LevelTargetBundle;
import net.minecraft.client.renderer.PostChain;
import net.minecraft.client.renderer.ShaderManager;
import net.minecraft.client.renderer.state.level.CameraRenderState;
import net.minecraft.client.renderer.texture.MissingTextureAtlasSprite;
import net.minecraft.core.HolderLookup;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.RegistryOps;
import net.minecraft.server.packs.resources.PreparableReloadListener;
import org.joml.Matrix4fc;
import org.lwjgl.system.MemoryStack;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.OptionalDouble;
import java.util.Set;

public class PostChainsManager extends ContentManager<PostChainActivator> {

    public static final String GLOBALS_NAME = "PolyGlobals";
    public static final String SHADOW_UBO_NAME = "PolyShadow";
    public static final String SHADOW_SAMPLER_NAME = "InShadow";
    public static final List<String> DYNAMIC_SAMPLERS = List.of(SHADOW_SAMPLER_NAME);

    private static volatile boolean globalsDeclared = false;
    private static volatile boolean shadowUboDeclared = false;
    private static volatile boolean shadowSamplerDeclared = false;

    private PolytoneGlobalUniforms globalUniforms = null;
    private GpuBuffer emptyShadowUbo = null;

    private final List<PostChainActivator> activators = new ArrayList<>();
    private final Map<Identifier, List<Map<String, Identifier>>> samplersByPassPipeline = new HashMap<>();

    private TextureTarget worldDepthSnapshot;
    private boolean worldDepthCaptured = false;
    private boolean levelRenderedThisFrame = false;

    public PostChainsManager() {
        super(Spec.of("Post chain", () -> PostChainActivator.CODEC)
                .wikiPage("Shaders")
                .folders("post_chains", "post_shaders"));
    }

    @Override
    protected AssetsFiles prepare(PreparableReloadListener.SharedState sharedState) {
        AssetsFiles resources = super.prepare(sharedState);
        ShaderUniformsManager.registerExpressionUniformNames(resources.jsons());
        return resources;
    }

    @Override
    protected void parseWithLevel(AssetsFiles resources, RegistryOps<JsonElement> ops, HolderLookup.Provider access) {
        synchronized (activators) {
            for (var j : parseEnabledJsons(resources.jsons(), ops)) {
                if (j != null) {
                    activators.add(j.getValue());
                }
            }
        }
    }

    @Override
    protected void resetWithLevel(boolean logOff) {
        synchronized (activators) {
            for (var a : activators) a.close();
            activators.clear();
        }
        samplersByPassPipeline.clear();
    }

    private GpuBufferSlice emptyShadowUbo() {
        if (emptyShadowUbo == null) {
            emptyShadowUbo = RenderSystem.getDevice().createBuffer(() -> "Polytone empty shadow UBO",
                    GpuBuffer.USAGE_COPY_DST | GpuBuffer.USAGE_UNIFORM, PolyShadowUniforms.UBO_SIZE);
            try (MemoryStack stack = MemoryStack.stackPush()) {
                RenderSystem.getDevice().createCommandEncoder()
                        .writeToBuffer(emptyShadowUbo.slice(), stack.calloc(PolyShadowUniforms.UBO_SIZE));
            }
        }
        return emptyShadowUbo.slice();
    }

    private PolytoneGlobalUniforms globalUniforms() {
        if (globalUniforms == null) {
            globalUniforms = new PolytoneGlobalUniforms();
        }
        return globalUniforms;
    }

    public static void onProgramLinked(Set<String> declaredUniforms) {
        if (declaredUniforms.contains(GLOBALS_NAME)) globalsDeclared = true;
        if (declaredUniforms.contains(SHADOW_UBO_NAME)) shadowUboDeclared = true;
    }

    public static void onDynamicSamplerDeclared(String name) {
        if (SHADOW_SAMPLER_NAME.equals(name)) shadowSamplerDeclared = true;
    }

    public boolean hasAnyPassBindings() {
        return globalsDeclared || shadowUboDeclared || shadowSamplerDeclared || !samplersByPassPipeline.isEmpty();
    }

    public void bindUniformBlocks(RenderPass pass, Set<String> declaredUniforms) {
        if (declaredUniforms.contains(GLOBALS_NAME)) {
            globalsDeclared = true;
            pass.setUniform(GLOBALS_NAME, globalUniforms().getSlice());
        }
        if (declaredUniforms.contains(SHADOW_UBO_NAME)) {
            GpuBufferSlice shadowSlice = Polytone.SHADOWS.renderer().getUniformsSlice();
            pass.setUniform(SHADOW_UBO_NAME, shadowSlice != null ? shadowSlice : emptyShadowUbo());
        }
    }

    public boolean anyActiveChainWantsShadowMap() {
        synchronized (activators) {
            for (var a : activators) {
                if (a.wantsShadowMap()) return true;
            }
        }
        return false;
    }

    public void registerSamplers(Identifier pipelineLocation, Map<String, Identifier> samplers) {
        if (samplers.isEmpty()) return;
        samplersByPassPipeline.computeIfAbsent(pipelineLocation, k -> new ArrayList<>()).add(samplers);
    }

    public void unregisterSamplers(Identifier pipelineLocation, Map<String, Identifier> samplers) {
        List<Map<String, Identifier>> list = samplersByPassPipeline.get(pipelineLocation);
        if (list != null) {
            list.remove(samplers);
            if (list.isEmpty()) samplersByPassPipeline.remove(pipelineLocation);
        }
    }

    public void bindSamplers(RenderPass pass, RenderPipeline pipeline, Set<String> declaredUniforms) {
        if (declaredUniforms.contains(SHADOW_SAMPLER_NAME)) {
            GpuTextureView shadowMap = Polytone.SHADOWS.renderer().getShadowTexture();
            if (shadowMap == null) {
                shadowMap = Minecraft.getInstance().getTextureManager()
                        .getTexture(MissingTextureAtlasSprite.getLocation()).getTextureView();
            }
            pass.setUniform(SHADOW_SAMPLER_NAME, shadowMap,
                    RenderSystem.getSamplerCache().getClampToEdge(FilterMode.NEAREST));
        }
        if (samplersByPassPipeline.isEmpty()) return;
        List<Map<String, Identifier>> list = samplersByPassPipeline.get(pipeline.getLocation());
        if (list == null) return;
        var textureManager = Minecraft.getInstance().getTextureManager();
        GpuSampler sampler = RenderSystem.getSamplerCache().getRepeat(FilterMode.LINEAR);
        for (Map<String, Identifier> samplers : list) {
            for (var e : samplers.entrySet()) {
                if (!declaredUniforms.contains(e.getKey())) continue;
                GpuTextureView view = textureManager.getTexture(e.getValue()).getTextureView();
                pass.setUniform(e.getKey(), view, sampler);
            }
        }
    }

    public void onClose() {
        synchronized (activators) {
            for (var a : activators) a.close();
        }
        if (globalUniforms != null) {
            globalUniforms.close();
            globalUniforms = null;
        }
        if (emptyShadowUbo != null) {
            emptyShadowUbo.close();
            emptyShadowUbo = null;
        }
        if (worldDepthSnapshot != null) {
            worldDepthSnapshot.destroyBuffers();
            worldDepthSnapshot = null;
        }
        Polytone.POST_TARGETS.close();
    }

    public void updateGlobalUniforms(Matrix4fc projectionMatrix, Matrix4fc viewMatrix, float deltaTime) {
        if (!globalsDeclared && !Polytone.isDevEnv) return;
        Minecraft mc = Minecraft.getInstance();
        float sunAngle = mc.levelRenderer.levelRenderState.skyRenderState.sunAngle;
        float dayTime = (float) ClientFrameTicker.getDayTime();
        globalUniforms().update(projectionMatrix, viewMatrix, sunAngle, dayTime, deltaTime);
    }

    public void tick() {
        synchronized (activators) {
            for (var a : activators) {
                a.refreshActive();
            }
        }
    }

    private List<PostChain> activeChains() {
        ShaderManager shaderManager = Minecraft.getInstance().getShaderManager();
        List<PostChain> active = new ArrayList<>();
        synchronized (activators) {
            for (var a : activators) {
                PostChain chain = a.getPostChain(shaderManager);
                if (chain != null) active.add(chain);
            }
        }
        return active;
    }

    private boolean anyActiveChainReadsMainDepth() {
        synchronized (activators) {
            for (var a : activators) {
                if (a.readsMainDepth()) return true;
            }
        }
        return false;
    }

    public void addChainsToFrameGraph(int width, int height, LevelTargetBundle targets, FrameGraphBuilder frameGraphBuilder,
                                      GpuBufferSlice fog, CameraRenderState cameraRenderState) {
        Polytone.POST_TARGETS.ensureAllocated(width, height);
        PostChain.TargetBundle bundle = Polytone.POST_TARGETS.wrap(targets, frameGraphBuilder);
        for (PostChain chain : activeChains()) {
            chain.addToFrame(frameGraphBuilder, width, height, bundle);
        }
    }

    public void snapshotWorldDepth(RenderTarget main) {
        levelRenderedThisFrame = true;
        worldDepthCaptured = false;
        if (!anyActiveChainReadsMainDepth()) return;
        ensureSnapshotSized(main.width, main.height);
        worldDepthSnapshot.copyDepthFrom(main);
        worldDepthCaptured = true;
    }

    public void runChainsAfterHand(RenderTarget main, GraphicsResourceAllocator resourceAllocator) {
        if (!levelRenderedThisFrame) return;
        levelRenderedThisFrame = false;

        List<PostChain> active = activeChains();
        if (active.isEmpty()) return;

        if (worldDepthCaptured) combineWorldDepthIntoMain(main);
        worldDepthCaptured = false;
        //not chain.process(): its bundle only holds main, so pack post_targets would be missing
        Polytone.POST_TARGETS.ensureAllocated(main.width, main.height);
        for (PostChain chain : active) {
            FrameGraphBuilder frameGraph = new FrameGraphBuilder();
            PostChain.TargetBundle mainOnly = PostChain.TargetBundle.of(PostChain.MAIN_TARGET_ID, frameGraph.importExternal("main", main));
            chain.addToFrame(frameGraph, main.width, main.height, Polytone.POST_TARGETS.wrap(mainOnly, frameGraph));
            frameGraph.execute(resourceAllocator);
        }
    }

    private void ensureSnapshotSized(int width, int height) {
        if (worldDepthSnapshot == null) {
            worldDepthSnapshot = new TextureTarget("Polytone World Depth Snapshot", width, height,
                    GpuFormat.RGBA8_UNORM, GpuFormat.D32_FLOAT);
        } else if (worldDepthSnapshot.width != width || worldDepthSnapshot.height != height) {
            worldDepthSnapshot.resize(width, height);
        }
    }

    private void combineWorldDepthIntoMain(RenderTarget main) {
        GpuTextureView worldDepth = worldDepthSnapshot.getDepthTextureView();
        GpuSampler sampler = RenderSystem.getSamplerCache().getClampToEdge(FilterMode.NEAREST);
        try (RenderPass pass = RenderSystem.getDevice().createCommandEncoder().createRenderPass(
                () -> "Polytone depth combine",
                main.getColorTextureView(), Optional.empty(),
                main.getDepthTextureView(), OptionalDouble.empty())) {
            pass.setPipeline(RenderSystem.getCompiledPipeline(PolytoneRenderTypes.DEPTH_COMBINE_PIPELINE));
            RenderSystem.bindDefaultUniforms(pass);
            pass.setUniform("InSampler", worldDepth, sampler);
            pass.draw(3, 1, 0, 0);
        }
    }
}
