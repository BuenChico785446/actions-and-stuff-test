package net.mehvahdjukaar.polytone.compat.nautilus;

import net.mehvahdjukaar.nautilus.NautilusStudioApi;
import net.mehvahdjukaar.nautilus.env.ClientEnvironment;
import net.mehvahdjukaar.polytone.Polytone;
import net.mehvahdjukaar.polytone.common.attributes.EnvironmentAttributeMapMod;
import net.mehvahdjukaar.polytone.common.attributes.IExtendedEnvAttrEntry;
import net.mehvahdjukaar.polytone.content.biome.BiomeEffectModifier;
import net.minecraft.core.HolderLookup;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.attribute.EnvironmentAttribute;
import net.minecraft.world.attribute.EnvironmentAttributeMap;
import net.minecraft.world.level.biome.Biome;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.List;

final class NautilusEnvironment implements ClientEnvironment.Contributor {

    static void register() {
        NautilusStudioApi.register(new NautilusEnvironment());
    }

    @Override
    public List<ClientEnvironment.Row> describe(EnvironmentAttribute<?> attribute,
                                               HolderLookup.Provider registries) {
        List<ClientEnvironment.Row> rows = new ArrayList<>();
        for (var e : Polytone.DIMENSION_MODIFIERS.modifiersById().entrySet()) {
            var mods = e.getValue().attributeModifications();
            String source = "dimension_modifiers/" + e.getKey().getPath();
            add(rows, attribute, registries, source, "dimension", mods.baseMod());
            add(rows, attribute, registries, source, "dimension, while raining", mods.rainMod());
            add(rows, attribute, registries, source, "dimension, while thundering", mods.thunderMod());
            add(rows, attribute, registries, source, "after the vanilla fold", mods.postProcess());
        }
        for (var e : Polytone.BIOME_MODIFIERS.modifiersByBiome().entrySet()) {
            BiomeEffectModifier.BiomeEnvAttributeModifications mods = e.getValue().attributeModifications();
            String source = "biome " + biomeName(registries, e.getKey());
            add(rows, attribute, registries, source, "biome", mods.baseMod());
            add(rows, attribute, registries, source, "after the vanilla fold", mods.postProcess());
        }
        return rows;
    }

    private static void add(List<ClientEnvironment.Row> rows, EnvironmentAttribute<?> attribute,
                            HolderLookup.Provider registries, String source, String stage,
                            EnvironmentAttributeMapMod mod) {
        if (mod.removes(attribute)) {
            rows.add(ClientEnvironment.Row.removal(source, stage,
                    "Drops the entry this map had, so the layer below shows through."));
            return;
        }
        EnvironmentAttributeMap.Entry<?, ?> entry = mod.getEntry(attribute);
        if (entry == null) return;

        rows.add(ClientEnvironment.Row.of(source, stage, attribute, entry, registries, dynamicNote(entry)));
    }

    private static @Nullable String dynamicNote(EnvironmentAttributeMap.Entry<?, ?> entry) {
        IExtendedEnvAttrEntry<?> ext = IExtendedEnvAttrEntry.of(entry);
        if (!ext.polytone$isDynamic()) return null;
        return ext.polytone$getBlend().biome()
                ? "Computed per frame from a colormap or expression, blended across biome borders."
                : "Computed per frame from a colormap or expression, sampled at the camera.";
    }

    private static String biomeName(HolderLookup.Provider registries, Biome biome) {
        return registries.lookup(Registries.BIOME)
                .flatMap(lookup -> lookup.listElements().filter(h -> h.value() == biome).findFirst())
                .map(h -> h.key().identifier().toString())
                .orElse("(unnamed)");
    }
}
