package net.mehvahdjukaar.polytone.mixins;

import net.mehvahdjukaar.polytone.content.slotify.SlotifyScreen;
import net.minecraft.client.gui.screens.inventory.SmithingScreen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyArg;

@Mixin(SmithingScreen.class)
public class SmithingScreenMixin {

    //TODO: add back

// TODO(dannyb) Figure out where these are now

//    @ModifyArg(method = "renderBg", at = @At(value = "INVOKE",
//            colormapToFill = "Lnet/minecraft/client/gui/screens/inventory/InventoryScreen;renderEntityInInventory(Lnet/minecraft/client/gui/GuiGraphicsExtractor;IIIIFLorg/joml/Vector3f;Lorg/joml/Quaternionf;Lorg/joml/Quaternionf;Lnet/minecraft/world/entity/LivingEntity;)V")
//            , index = 1
//    )
    public int modifyRenderEntityX(int x) {
        var m = ((SlotifyScreen) this).polytone$getModifier();
        if (m != null) {

            var s = m.getSpecial("player");
            if (s != null) {
                return x + s.x();
            }
        }

        return x;
    }

//    @ModifyArg(method = "renderBg", at = @At(value = "INVOKE",
//            colormapToFill = "Lnet/minecraft/client/gui/screens/inventory/InventoryScreen;renderEntityInInventory(Lnet/minecraft/client/gui/GuiGraphicsExtractor;IIIIFLorg/joml/Vector3f;Lorg/joml/Quaternionf;Lorg/joml/Quaternionf;Lnet/minecraft/world/entity/LivingEntity;)V")
//            , index = 2
//    )
    public int modifyRenderEntityY(int y) {
        var m = ((SlotifyScreen) this).polytone$getModifier();
        if (m != null) {
            var s = m.getSpecial("player");
            if (s != null) {
                return y + s.y();
            }
        }
        return y;
    }

//    @ModifyArg(method = "renderBg", at = @At(value = "INVOKE",
//            colormapToFill = "Lnet/minecraft/client/gui/screens/inventory/InventoryScreen;renderEntityInInventory(Lnet/minecraft/client/gui/GuiGraphicsExtractor;IIIIFLorg/joml/Vector3f;Lorg/joml/Quaternionf;Lorg/joml/Quaternionf;Lnet/minecraft/world/entity/LivingEntity;)V")
//            , index = 5
//    )
    public float modifyRenderEntityScale(float z) {
        var m = ((SlotifyScreen) this).polytone$getModifier();
        if (m != null) {
            var s = m.getSpecial("player");
            if (s != null) {
                return z + s.scale();
            }
        }
        return z;
    }
}
