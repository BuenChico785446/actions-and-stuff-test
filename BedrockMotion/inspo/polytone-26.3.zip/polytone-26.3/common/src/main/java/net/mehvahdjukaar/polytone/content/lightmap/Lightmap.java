package net.mehvahdjukaar.polytone.content.lightmap;

import com.mojang.renderpearl.backend.opengl.GlStateManager;
import com.mojang.renderpearl.api.textures.GpuTextureView;
import com.mojang.serialization.Codec;
import net.mehvahdjukaar.codecui.SchemaCodec;
import net.mehvahdjukaar.codecui.SchemaRecord;
import net.mehvahdjukaar.polytone.Polytone;
import net.mehvahdjukaar.polytone.content.dimension.DimensionTarget;
import net.mehvahdjukaar.polytone.common.ColorUtils;
import net.mehvahdjukaar.codecui.SchemaCodecs;
import net.mehvahdjukaar.polytone.common.struc.ArrayImage;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.util.Mth;
import org.jetbrains.annotations.Nullable;
import org.joml.Vector3f;
import org.lwjgl.opengl.GL20C;
import org.lwjgl.system.MemoryUtil;

import java.lang.ref.Cleaner;

public class Lightmap {

    protected static final double DEFAULT_SKY_LERP = 0.1;
    protected static final double DEFAULT_TORCH_LERP = 0;
    protected static final float DEFAULT_BASE_LIGHT = 0.04f;


    public static final SchemaCodec<Lightmap> DIRECT_CODEC = SchemaRecord.create(Lightmap.class, i ->
            i.group(
                    i.optional("targets", DimensionTarget.CODEC, DimensionTarget.EMPTY,
                            l -> l.targets),
                    i.optional("sky_getter", ILightmapNumberProvider.CODEC, ILightmapNumberProvider.DEFAULT,
                            l -> l.skyGetter),
                    i.optional("torch_getter", ILightmapNumberProvider.CODEC, ILightmapNumberProvider.DEFAULT,
                            l -> l.torchGetter),
                    i.optional("lightning_strike_columns", Codec.BOOL, true,
                            l -> l.hasLightningColumn),
                    i.optional("sky_lerp_factor", Codec.doubleRange(0, 1), DEFAULT_SKY_LERP,
                            l -> l.skyLerp),
                    i.optional("torch_lerp_factor", Codec.doubleRange(0, 1), DEFAULT_TORCH_LERP,
                            l -> l.torchLerp),
                    i.optional("base_light", Codec.FLOAT, DEFAULT_BASE_LIGHT, l -> l.baseLight)
            ).apply(i, Lightmap::new));

    public static final Codec<Lightmap> CODEC = SchemaCodecs.referenceOrDirect(Polytone.LIGHTMAPS.byNameCodec(), DIRECT_CODEC);


    private final DimensionTarget targets;
    private final ILightmapNumberProvider skyGetter;
    private final ILightmapNumberProvider torchGetter;
    private final boolean hasLightningColumn;
    private final float baseLight;
    private final double skyLerp;
    private final double torchLerp;
    private final ArrayImage[] textures = new ArrayImage[3];

    private final float[][] lastSkyLine = new float[16][3];
    private final float[][] lastTorchLine = new float[16][3];
    private final long lightmapPixels;
    private boolean lastThunderFlash = false;

    private long lastTime = 0;
    private boolean forceUpload = false;

    public Lightmap(DimensionTarget targets, ILightmapNumberProvider skyGetter, ILightmapNumberProvider torchGetter,
                    boolean lightningColumn, double skyLerp, double torchLerp, float baseLight) {
        this.skyGetter = skyGetter;
        this.torchGetter = torchGetter;
        this.hasLightningColumn = lightningColumn;
        this.skyLerp = skyLerp;
        this.torchLerp = torchLerp;
        this.baseLight = baseLight;
        long pixels = MemoryUtil.nmemAlloc(16 * 16 * 4);
        Cleaner.create().register(this, () -> MemoryUtil.nmemFree(pixels));
        this.lightmapPixels = pixels;
        this.targets = targets;
    }

    //default impl
    public Lightmap() {
        this(DimensionTarget.EMPTY, ILightmapNumberProvider.DEFAULT, ILightmapNumberProvider.RANDOM, true,
                DEFAULT_SKY_LERP, DEFAULT_TORCH_LERP, DEFAULT_BASE_LIGHT);
    }

    public void acceptImages(ArrayImage normal, ArrayImage rain, ArrayImage thunder) {
        this.textures[0] = normal;
        this.textures[1] = rain;
        this.textures[2] = thunder;
        for (var v : textures) {
            if (v != null && v.width() <= 2) {
                throw new IllegalStateException("Lightmap cannot have more with is too small! Was " + v.width());
            }
        }
    }

    public DimensionTarget targets() {
        return targets;
    }


    public void forceRefresh(){
        this.forceUpload = true;
    }

    //TODO:this needs to go into a shader
    //way too much to edit to use mixins, plus we lerp so overriding entirely is probably best way anyways
    public void applyToLightTexture(Object instance,
                                    GpuTextureView lightmap,
                                    Minecraft minecraft, ClientLevel level,
                                    float flicker, float partialTicks) {
/*
        // this makes a copy
        boolean needsUpload = false;
        if(forceUpload){
            forceUpload = false;
            needsUpload = true;
        }

        //this wasn't using partial ticks for some reasons
        float skyDarken = level.getSkyDarken(partialTicks);
        float rainLevel = level.getRainLevel(partialTicks);
        float thunderLevel = level.getThunderLevel(partialTicks);
        float time = level.getTimeOfDay(partialTicks);
        long currentTime = System.currentTimeMillis();
        long deltaMillis = currentTime - lastTime;
        float deltaTime = deltaMillis / 1000.0F;
        lastTime = currentTime;
        LocalPlayer player = minecraft.player;
        Options options = minecraft.options;

        float skyLightIntensity;
        boolean skyFlashTime = level.getSkyFlashTime() > 0;
        if (skyFlashTime) {
            skyLightIntensity = 1.0F;
        } else {
            skyLightIntensity = skyDarken * 0.95F + 0.05F;
        }

        float darknessEffect = options.darknessEffectScale().get().floatValue();

        float darknessGamma = player.getEffectBlendFactor(MobEffects.DARKNESS, partialTicks) * darknessEffect;
        float darknessSubtract = instance.calculateDarknessScale(player, darknessGamma, partialTicks) * darknessEffect;

        float gamma = (options.gamma().get()).floatValue();
        //INSERTION BY AC
        gamma = PlatStuff.compatACModifyGamma(partialTicks, gamma);

        float gammaAmount = Math.max(0.0F, gamma - darknessGamma);

        float waterVision = player.getWaterVision();
        float nightVisionScale;
        if (player.hasEffect(MobEffects.NIGHT_VISION)) {
            nightVisionScale = GameRenderer.nightVisionScale(player, partialTicks);
        } else if (waterVision > 0.0F && player.hasEffect(MobEffects.CONDUIT_POWER)) {
            nightVisionScale = waterVision;
        } else {
            nightVisionScale = 0.0F;
        }

        Vector3f skyColor = (new Vector3f(skyDarken, skyDarken, 1.0F))
                .lerp(new Vector3f(1.0F, 1.0F, 1.0F), 0.35F);
        float blockLightFlicker = flicker + 1.5F;
        //boolean endBright = level.effects().hasEndFlashes();
        DimensionType dimensionType = level.dimensionType();

        float darkenWorldAmount = minecraft.gameRenderer.getDarkenWorldAmount(partialTicks);


        Vector3f lightGray = new Vector3f(0.75F, 0.75F, 0.75F);
        float lightGrayAmount = baseLight;

        ArrayImage image = selectImage(rainLevel, thunderLevel);
        float[][] torchLine = selectTorch(image, nightVisionScale, time, rainLevel, thunderLevel);
        float[][] skyLine = selectSky(image, nightVisionScale, time, rainLevel, thunderLevel, skyFlashTime);

        // we need pow to simulate multiple lerps

        //lerp!

        if (torchLine.length != 0 && lastTorchLine.length != 0 && torchLerp != 0) {
            float lerpDelta = 1 - (float) Math.pow(torchLerp, deltaTime);
            lerpInplace(lastTorchLine, torchLine, lerpDelta);
        }
        if (skyLine.length != 0 && lastSkyLine.length != 0 && skyLerp != 0) {
            float lerpDelta = 1 - (float) Math.pow(skyLerp, deltaTime);
            if (skyFlashTime || lastThunderFlash) {
                lerpDelta = 1; //no lerp during thunder flash
            }
            lerpInplace(lastSkyLine, skyLine, lerpDelta);
        }
        if (skyFlashTime) {
            lastThunderFlash = true;
        } else if (lastThunderFlash) {
            lastThunderFlash = false;
        }

        for (int skyY = 0; skyY < 16; ++skyY) {
            Vector3f skyBuffer = new Vector3f();

            if (skyLine.length != 0) {
                skyBuffer.add(new Vector3f(skyLine[skyY]));
            } else {
                // we have no colors. use vanilla logic
                float skyBrightness = net.minecraft.client.renderer.Lightmap.getBrightness(dimensionType,skyY) * skyLightIntensity;
                skyBuffer.add(skyColor).mul(skyBrightness);
                skyBuffer.mul(1 - lightGrayAmount);
            }

            for (int torchX = 0; torchX < 16; ++torchX) {
                Vector3f addition = new Vector3f();
                Vector3f torchBuffer = new Vector3f();

                if (torchLine.length != 0) {
                    torchBuffer.add(new Vector3f(torchLine[torchX]));
                } else {
                    // we have no colors. use vanilla logic
                    float torchR = net.minecraft.client.renderer.Lightmap.getBrightness(dimensionType,torchX) * blockLightFlicker;
                    float torchG = torchR * ((torchR * 0.6F + 0.4F) * 0.6F + 0.4F);
                    float torchB = torchR * (torchR * torchR * 0.6F + 0.4F);
                    torchBuffer.set(torchR, torchG, torchB);

                    //vanilla logic
                    addition.add(new Vector3f(lightGray).mul(lightGrayAmount));

                    //torchBuffer.lerp(lightGray, lightGrayAmount);
                    torchBuffer.mul(1 - lightGrayAmount);
                }


                Vector3f combined = new Vector3f();

                combined.add(torchBuffer).add(skyBuffer).add(addition);

                if (darkenWorldAmount > 0.0F) {
                    Vector3f discolored = (new Vector3f(combined)).mul(0.7F, 0.6F, 0.6F);
                    combined.lerp(discolored, darkenWorldAmount);
                }

                PlatStuff.adjustLightmapColors(level, partialTicks, skyDarken, skyLightIntensity, flicker, torchX, skyY, combined);

                if (nightVisionScale > 0.0F && (image == null || image.height() <= 32)) {
                    float maxVal = Math.max(combined.x(), Math.max(combined.y(), combined.z()));
                    if (maxVal < 1.0F) {
                        float percentage = 1.0F / maxVal;
                        Vector3f discolored = (new Vector3f(combined)).mul(percentage);
                        combined.lerp(discolored, nightVisionScale);
                    }
                }

                //we make both hse happen in end too
                if (darknessSubtract > 0.0F) {
                    combined.add(-darknessSubtract, -darknessSubtract, -darknessSubtract);
                }

                clampColor(combined);

                //apply gamma
                Vector3f notGamma = new Vector3f(
                        notGamma(combined.x),
                        notGamma(combined.y),
                        notGamma(combined.z));
                combined.lerp(notGamma, gammaAmount);
                //guess this makes it so its never pitch dark
                combined.lerp(lightGray, lightGrayAmount);
                clampColor(combined);
                combined.mul(255.0F);
                long pixel = ((long)torchX + (long)skyY * 16L) * 4L;

                int x = (int) combined.x();
                int y = (int) combined.y();
                int z = (int) combined.z();
                int newColor = -16777216 | z << 16 | y << 8 | x;
                int oldTexture = MemoryUtil.memGetInt(lightmapPixels + pixel);

                if (newColor != oldTexture) {
                    needsUpload = true;
                    MemoryUtil.memPutInt(lightmapPixels + pixel, newColor);
                }
            }
        }

        if (needsUpload) {
            resetTextureUploadState();
            RenderSystem.bindTextureForSetup(lightmap.getColorTextureId());
            GlStateManager._texSubImage2D(3553, 0, 0, 0, 16, 16, NativeImage.Format.RGBA.glFormat(), 5121, lightmapPixels);
        }
 */
    }

    public static void resetTextureUploadState() {
        // Ensure that the pixel storage mode is in a sane state, otherwise the uploaded texture data will be quite
        // incorrect.
        //
        // It is likely that this also avoids the crashes on AMD that I previously experienced with texture creation.
        //
        // This code is from Canvas: https://github.com/grondag/canvas/commit/f0ab652d7a8b7cc9febf0209bee15cffce9eac83
        GlStateManager._pixelStore(GL20C.GL_UNPACK_ROW_LENGTH, 0);
        GlStateManager._pixelStore(GL20C.GL_UNPACK_SKIP_ROWS, 0);
        GlStateManager._pixelStore(GL20C.GL_UNPACK_SKIP_PIXELS, 0);
        GlStateManager._pixelStore(GL20C.GL_UNPACK_ALIGNMENT, 4);
    }

    private float notGamma(float f) {
        float g = 1.0F - f;
        return 1.0F - g * g * g * g;
    }

    private float[][] selectSky(ArrayImage image, float nightVision, float time, float rain, float thunder,
                                boolean isThunderFlash) {
        if (image == null) {
            return new float[][]{};
        }
        double xVal = skyGetter.getValue(time, rain, thunder);

        float[][] skyLine = new float[16][];

        int usableSkyWidth = image.width() - 1 - (this.hasLightningColumn ? 1 : 0);
        int w;
        if (!isThunderFlash || !hasLightningColumn) {
            if (isThunderFlash) {
                //default thunder lightmap
                w = usableSkyWidth;
            } else {
                //no thunder
                w = Math.round((float) xVal * usableSkyWidth);
            }
        } else {
            //thunder lightmap
            w = usableSkyWidth + 1;
        }
        int h = ((nightVision != 0 && image.height() == 64) ? 32 : 0);
        for (int i = 0; i < 16; i++) {
            skyLine[i] = ColorUtils.unpack(image.pixels()[h + i][w]);
        }
        return skyLine;
    }


    private float[][] selectTorch(ArrayImage image, float nightVision, float time, float rain, float thunder) {

        if (image == null || image.height() < 32) {
            return new float[][]{};
        }
        double xVal = torchGetter.getValue(time, rain, thunder);
        //simulate torch flicker
        float[][] torchLine = new float[16][];
        int h = 16 + ((nightVision != 0 && image.height() == 64) ? 32 : 0);
        for (int i = 0; i < 16; i++) {
            torchLine[i] = ColorUtils.unpack(image.pixels()[h + i][(int) (xVal * (image.width() - 1))]);
        }
        return torchLine;
    }

    @Nullable
    private ArrayImage selectImage(float rain, float thunder) {
        ArrayImage image;
        if (thunder != 0) {
            image = textures[2];
            if (image == null) {
                image = textures[0];
            }
        } else if (rain != 0) {
            image = textures[1];
            if (image == null) {
                image = textures[0];
            }
        } else image = textures[0];
        return image;
    }

    private static void clampColor(Vector3f color) {
        color.set(Mth.clamp(color.x, 0.0F, 1.0F),
                Mth.clamp(color.y, 0.0F, 1.0F),
                Mth.clamp(color.z, 0.0F, 1.0F));
    }

    public static void lerpInplace(float[][] oldColors, float[][] newColors, float delta) {
        if (oldColors.length != newColors.length || oldColors[0].length != newColors[0].length) {
            throw new IllegalArgumentException("Input arrays must have the same dimensions.");
        }

        int numRows = oldColors.length;
        int numCols = oldColors[0].length;

        for (int i = 0; i < numRows; i++) {
            for (int j = 0; j < numCols; j++) {
                newColors[i][j] = Mth.lerp(delta, oldColors[i][j], newColors[i][j]);
            }
        }
        //saves for next cycle
        for (int i = 0; i < numRows; i++) {
            System.arraycopy(newColors[i], 0, oldColors[i], 0, numCols);
        }
    }

}
