package net.mehvahdjukaar.polytone.mixins;

import com.mojang.blaze3d.vertex.PoseStack;
import net.mehvahdjukaar.polytone.Polytone;
import net.minecraft.client.model.Model;
import net.minecraft.client.renderer.SubmitNodeStorage;
import net.minecraft.client.renderer.entity.state.EntityRenderState;
import net.minecraft.client.renderer.rendertype.RenderType;
import net.minecraft.client.renderer.texture.UvMapping;
import org.jspecify.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(SubmitNodeStorage.class)
public class SubmitNodeStorageMixin {

    @Inject(method = "submitModel", at = @At("HEAD"))
    private <S> void polytone$onSubmitModel(Model<? super S> model, S object, PoseStack poseStack,
                                                                      RenderType renderType, int i, int j, int k,
                                                                      @Nullable UvMapping uvMapping, int l,
                                                                      CallbackInfo ci) {
        //Cant use forge events as they are missing the camera state
        if (object instanceof EntityRenderState state) {
            Polytone.ENTITY_MODIFIERS.onEntityRender((Model<? super EntityRenderState>) model, poseStack, state);
        }
    }
}
