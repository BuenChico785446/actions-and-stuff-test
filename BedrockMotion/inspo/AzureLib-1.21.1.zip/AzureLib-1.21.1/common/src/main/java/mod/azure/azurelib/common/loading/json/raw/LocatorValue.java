/**
 * This class is a fork of the matching class found in the Geckolib repository. Original source:
 * https://github.com/bernie-g/geckolib Copyright © 2024 Bernie-G. Licensed under the MIT License.
 * https://github.com/bernie-g/geckolib/blob/main/LICENSE
 */
package mod.azure.azurelib.common.loading.json.raw;

import com.google.gson.JsonDeserializer;
import com.google.gson.JsonParseException;
import org.jetbrains.annotations.Nullable;

import mod.azure.azurelib.common.util.JsonUtil;

/**
 * Container class for locator value information, only used in deserialization at startup
 */
public record LocatorValue(
    @Nullable LocatorClass locatorClass,
    double[] values
) {

    public static JsonDeserializer<LocatorValue> deserializer() throws JsonParseException {
        return (json, type, context) -> {
            if (json.isJsonArray()) {
                return new LocatorValue(null, JsonUtil.jsonArrayToDoubleArray(json.getAsJsonArray()));
            } else if (json.isJsonObject()) {
                return new LocatorValue(context.deserialize(json.getAsJsonObject(), LocatorClass.class), new double[0]);
            } else {
                throw new JsonParseException("Invalid format for LocatorValue in json");
            }
        };
    }
}
