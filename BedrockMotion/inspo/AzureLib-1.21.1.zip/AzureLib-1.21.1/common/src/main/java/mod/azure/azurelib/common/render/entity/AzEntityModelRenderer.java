package mod.azure.azurelib.common.render.entity;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import net.minecraft.client.renderer.entity.LivingEntityRenderer;
import net.minecraft.core.Direction;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Pose;
import org.jetbrains.annotations.Nullable;
import org.joml.Matrix4f;

import java.util.UUID;

import mod.azure.azurelib.common.animation.impl.AzEntityAnimator;
import mod.azure.azurelib.common.model.AzBakedModel;
import mod.azure.azurelib.common.model.AzBone;
import mod.azure.azurelib.common.render.AzLayerRenderer;
import mod.azure.azurelib.common.render.AzModelRenderer;
import mod.azure.azurelib.common.render.AzRendererPipelineContext;
import mod.azure.azurelib.common.util.client.RenderUtils;

/**
 * AzEntityModelRenderer is a class responsible for rendering animated 3D entity models in a pipeline-based rendering
 * setup. Extends the {@link AzModelRenderer} class and utilizes the {@link AzEntityRendererPipeline} to handle various
 * rendering tasks, such as applying model transformations and managing animated states in the rendering lifecycle. <br>
 *
 * @param <T> The type of entity that this renderer applies to, extends the {@link Entity} class.
 */
public class AzEntityModelRenderer<T extends Entity> extends AzModelRenderer<UUID, T> {

    protected final AzEntityRendererPipeline<T> entityRendererPipeline;

    private final Matrix4f scratchPoseState = new Matrix4f();

    private final Matrix4f scratchLocalMatrix = new Matrix4f();

    public AzEntityModelRenderer(
        AzEntityRendererPipeline<T> entityRendererPipeline,
        AzLayerRenderer<UUID, T> layerRenderer
    ) {
        super(entityRendererPipeline, layerRenderer);
        this.entityRendererPipeline = entityRendererPipeline;
    }

    /**
     * The actual render method that subtype renderers should override to handle their specific rendering tasks.<br>
     * {@link AzEntityRendererPipeline#preRender} has already been called by this stage, and
     * {@link AzEntityRendererPipeline#postRender} will be called directly after
     */
    @Override
    public void render(AzRendererPipelineContext<UUID, T> context, boolean isReRender) {
        var animatable = context.animatable();
        var partialTick = context.partialTick();
        var poseStack = context.poseStack();

        poseStack.pushPose();
        applyEntityTransforms(animatable, poseStack, partialTick);

        if (!isReRender || context.applyAnimationOnReRender()) {
            var renderer = entityRendererPipeline.getRenderer();
            var animator = renderer.getAnimator();

            if (animator != null && renderer.shouldAnimateThisFrame()) {
                handleAnimation(animator, animatable, context.partialTick());
            }
        }

        entityRendererPipeline.modelRenderTranslations.set(poseStack.last().pose());

        if (context.vertexConsumer() != null) {
            super.render(context, isReRender);
        }

        poseStack.popPose();
    }

    private void applyEntityTransforms(T animatable, PoseStack poseStack, float partialTick) {
        float lerpBodyRot = getLerpRot(animatable, partialTick);

        if (animatable.getPose() == Pose.SLEEPING && animatable instanceof LivingEntity livingEntity) {
            Direction bedDirection = livingEntity.getBedOrientation();

            if (bedDirection != null) {
                float eyePosOffset = livingEntity.getEyeHeight(Pose.STANDING) - 0.1F;

                poseStack.translate(
                    -bedDirection.getStepX() * eyePosOffset,
                    0,
                    -bedDirection.getStepZ() * eyePosOffset
                );
            }
        }

        float nativeScale = animatable instanceof LivingEntity livingEntity ? livingEntity.getScale() : 1;
        float ageInTicks = animatable.tickCount + partialTick;

        poseStack.scale(nativeScale, nativeScale, nativeScale);
        applyRotations(animatable, poseStack, ageInTicks, lerpBodyRot, partialTick, nativeScale);
    }

    public void poseBonesOffscreen(
        T animatable,
        AzBakedModel model,
        @Nullable AzEntityAnimator<T> animator,
        float partialTick
    ) {
        var poseStack = new PoseStack();
        var config = entityRendererPipeline.getRenderer().config();
        var scaleWidth = config.scaleWidth(animatable);
        var scaleHeight = config.scaleHeight(animatable);

        entityRendererPipeline.entityRenderTranslations.identity();

        if (scaleWidth != 1 || scaleHeight != 1) {
            poseStack.scale(scaleWidth, scaleHeight, scaleWidth);
        }

        applyEntityTransforms(animatable, poseStack, partialTick);

        if (animator != null) {
            handleAnimation(animator, animatable, partialTick);
        }

        entityRendererPipeline.modelRenderTranslations.set(poseStack.last().pose());

        for (var bone : model.getTopLevelBones()) {
            poseBoneOffscreen(animatable, poseStack, bone);
        }
    }

    private void poseBoneOffscreen(T animatable, PoseStack poseStack, AzBone bone) {
        if (bone.isHidden()) {
            if (!bone.isHidingChildren()) {
                for (var child : bone.getChildBones()) {
                    poseBoneOffscreen(animatable, poseStack, child);
                }
            }
            return;
        }

        if (bone.getScaleX() == 0f && bone.getScaleY() == 0f && bone.getScaleZ() == 0f) {
            return;
        }

        poseStack.pushPose();
        RenderUtils.translateMatrixToBone(poseStack, bone);
        RenderUtils.translateToPivotPoint(poseStack, bone);
        RenderUtils.rotateMatrixAroundBone(poseStack, bone);
        RenderUtils.scaleMatrixForBone(poseStack, bone);

        if (bone.isTrackingMatrices()) {
            trackBoneMatrices(animatable, bone, poseStack.last().pose());
        }

        RenderUtils.translateAwayFromPivotPoint(poseStack, bone);

        if (!bone.isHidingChildren()) {
            for (var child : bone.getChildBones()) {
                poseBoneOffscreen(animatable, poseStack, child);
            }
        }

        poseStack.popPose();
    }

    private void trackBoneMatrices(T entity, AzBone bone, Matrix4f pose) {
        scratchPoseState.set(pose);
        var localMatrix = RenderUtils.invertAndMultiplyMatrices(
            scratchPoseState,
            entityRendererPipeline.entityRenderTranslations
        );
        bone.setModelSpaceMatrix(
            RenderUtils.invertAndMultiplyMatrices(
                scratchPoseState,
                entityRendererPipeline.modelRenderTranslations
            )
        );
        scratchLocalMatrix.set(localMatrix);
        RenderUtils.translateMatrixInPlace(
            scratchLocalMatrix,
            entityRendererPipeline.getRenderer().getRenderOffset(entity, 1).toVector3f()
        );
        bone.setLocalSpaceMatrix(localMatrix);
        bone.setWorldSpaceMatrix(scratchLocalMatrix);
    }

    /**
     * Renders the provided {@link AzBone} and its associated child bones
     */
    @Override
    public void renderRecursively(AzRendererPipelineContext<UUID, T> context, AzBone bone, boolean isReRender) {
        if (bone.isHidden()) {
            if (!bone.isHidingChildren()) {
                renderChildBones(context, bone, isReRender);
            }
            return;
        }

        if (bone.getScaleX() == 0f && bone.getScaleY() == 0f && bone.getScaleZ() == 0f) {
            return;
        }

        var buffer = context.vertexConsumer();
        var bufferSource = context.multiBufferSource();
        var entity = context.animatable();
        var poseStack = context.poseStack();

        var slot = saveBonePose(poseStack);

        try {
            RenderUtils.translateMatrixToBone(poseStack, bone);
            RenderUtils.translateToPivotPoint(poseStack, bone);
            RenderUtils.rotateMatrixAroundBone(poseStack, bone);
            RenderUtils.scaleMatrixForBone(poseStack, bone);

            if (bone.isTrackingMatrices()) {
                trackBoneMatrices(entity, bone, poseStack.last().pose());
            }

            RenderUtils.translateAwayFromPivotPoint(poseStack, bone);

            context.setVertexConsumer(getOrRefreshRenderBuffer(isReRender, context, bone));

            if (
                !boneRenderOverride(
                    poseStack,
                    bone,
                    bufferSource,
                    buffer,
                    context.partialTick(),
                    context.packedLight(),
                    context.packedOverlay(),
                    context.renderColor()
                )
            )
                super.renderCubesOfBone(context, bone);

            if (!isReRender) {
                layerRenderer.applyRenderLayersForBone(context, bone);
            }

            renderChildBones(context, bone, isReRender);
        } finally {
            restoreBonePose(poseStack, slot);
        }
    }

    /**
     * Calculates a linear interpolation (LERP) rotation value for a given entity, taking into account the entity's
     * current and previous rotations, its head movement, and whether it is mounted on another entity. Specifically,
     * this method interpolates between the previous and current rotation states, constraining rotational adjustments to
     * ensure realistic movement, especially when the entity is a passenger.
     *
     * @param animatable  The entity whose rotation is to be interpolated. Must extend {@link Entity}, and may include
     *                    subtypes such as {@link LivingEntity} to apply specific logic for living entities.
     * @param partialTick A float value representing the partial time progression within the current game tick. Used to
     *                    blend between previous and current states for smoother animations.
     * @return The interpolated LERP rotation value, which represents the adjusted body rotation of the entity after
     *         considering multiple elements such as head movements and passenger state.
     */
    private static <T extends Entity> float getLerpRot(T animatable, float partialTick) {
        boolean shouldSit = animatable.isPassenger() && (animatable.getVehicle() != null);

        float lerpBodyRot = animatable instanceof LivingEntity livingEntity
            ? Mth.rotLerp(
                partialTick,
                livingEntity.yBodyRotO,
                livingEntity.yBodyRot
            )
            : animatable.getYRot();
        float lerpHeadRot = animatable instanceof LivingEntity livingEntity
            ? Mth.rotLerp(
                partialTick,
                livingEntity.yHeadRotO,
                livingEntity.yHeadRot
            )
            : animatable.getYHeadRot();

        if (shouldSit && animatable.getVehicle() instanceof LivingEntity livingentity) {
            lerpBodyRot = Mth.rotLerp(partialTick, livingentity.yBodyRotO, livingentity.yBodyRot);
            float netHeadYaw = lerpHeadRot - lerpBodyRot;
            float clampedHeadYaw = Mth.clamp(Mth.wrapDegrees(netHeadYaw), -85, 85);
            lerpBodyRot = lerpHeadRot - clampedHeadYaw;

            if (clampedHeadYaw * clampedHeadYaw > 2500f)
                lerpBodyRot += clampedHeadYaw * 0.2f;
        }
        return lerpBodyRot;
    }

    /**
     * Applies rotation transformations to the renderer prior to render time to account for various entity states,
     * scalable
     */
    protected void applyRotations(
        T animatable,
        PoseStack poseStack,
        float ageInTicks,
        float rotationYaw,
        float partialTick,
        float nativeScale
    ) {
        if (animatable.isFullyFrozen()) {
            rotationYaw += (float) (Math.cos(animatable.tickCount * 3.25d) * Math.PI * 0.4d);
        }

        if (!animatable.hasPose(Pose.SLEEPING)) {
            poseStack.mulPose(Axis.YP.rotationDegrees(180f - rotationYaw));
        }

        if (animatable instanceof LivingEntity livingEntity) {
            var config = entityRendererPipeline.getRenderer().config();
            var deathMaxRotation = config.getDeathMaxRotation(animatable);

            if (livingEntity.deathTime > 0) {
                float deathRotation = (livingEntity.deathTime + partialTick - 1f) / 20f * 1.6f;

                poseStack.mulPose(
                    Axis.ZP.rotationDegrees(Math.min(Mth.sqrt(deathRotation), 1) * deathMaxRotation)
                );
            } else if (livingEntity.isAutoSpinAttack()) {
                poseStack.mulPose(Axis.XP.rotationDegrees(-90f - livingEntity.getXRot()));
                poseStack.mulPose(Axis.YP.rotationDegrees((livingEntity.tickCount + partialTick) * -75f));
            } else if (animatable.hasPose(Pose.SLEEPING)) {
                Direction bedOrientation = livingEntity.getBedOrientation();

                poseStack.mulPose(
                    Axis.YP.rotationDegrees(
                        bedOrientation != null ? RenderUtils.getDirectionAngle(bedOrientation) : rotationYaw
                    )
                );
                poseStack.mulPose(Axis.ZP.rotationDegrees(deathMaxRotation));
                poseStack.mulPose(Axis.YP.rotationDegrees(270f));
            } else if (LivingEntityRenderer.isEntityUpsideDown(livingEntity)) {
                poseStack.translate(0, (animatable.getBbHeight() + 0.1f) / nativeScale, 0);
                poseStack.mulPose(Axis.ZP.rotationDegrees(180f));
            }
        }
    }
}
